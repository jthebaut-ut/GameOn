import Combine
import CoreLocation
import MapKit
import SwiftUI

enum WatchingExpiredVenueGameDiagnostics {
    nonisolated static let enabled = false
}

enum SavedProGameStatusDiagnostics {
    nonisolated static let enabled = true
}

struct FollowingScreen: View {
    @ObservedObject var viewModel: MapViewModel
    @Binding var selectedTab: MainTabView.AppTab
    @EnvironmentObject private var chatViewModel: ChatViewModel
    var suppressInitialAutoRefresh = false
    var isFollowingTabSelected: Bool = true

    @Environment(\.colorScheme) private var followingColorScheme
    @Environment(\.scenePhase) private var scenePhase
    @State private var favoriteActionBanner: String?
    @State private var didHandleInitialAutoRefresh = false

    /// Venue events the user marked "Interested" from Following without a Supabase row (table has no status column).
    @AppStorage("gameon.following.interestedOnlyVenueEventIDs") private var interestedOnlyEncoded: String = ""
    @AppStorage(FavoriteTeamsStore.appStorageKey) private var favoriteTeamIDsRaw: String = ""
    @AppStorage(ProGamesFavoriteTeamAutoFollowPreference.enabledKey) private var proGamesAutoFollowFavoriteTeams = false
    @AppStorage(ProGamesFavoriteTeamAutoFollowPreference.windowDaysKey) private var proGamesFavoriteTeamWindowDays = ProGamesFavoriteTeamAutoFollowPreference.Window.next30.rawValue
    @AppStorage(ProGameNotificationPreferenceKeys.favoriteTeamAlerts) private var favoriteTeamProGameAlertsEnabled = false
    @AppStorage("gameon.going.completedFavoriteTeamProGamesCleared.v1") private var clearedCompletedFavoriteTeamProGamesRaw: String = ""
    @State private var pickupDetailNav: PickupDetailNavigationToken?
    @State private var followingPickupWithdrawConfirm: PickupJoinWithdrawConfirmState?
    @State private var followingPickupWithdrawInFlight = false

    @State private var followingMyPickupClockTick: Date = Date()
    @State private var followingMyPickupFormMode: PickupGameFormMode?
    @State private var followingMyPickupDeleteTarget: PickupGameRow?
    @State private var followingMyPickupOrganizerRequestsGame: PickupGameRow?
    @State private var followingMyPickupDetailGame: PickupGameRow?
    @State private var proGamePredictionSheet: ProGamePredictionSheetContext?
    @State private var proGameMatchDetailSelection: LiveMatch?
    @State private var pendingProGameNotificationMatchID: String?
    @State private var followingPickupInviteGame: PickupGameRow?
    @State private var followingPickupInviteDetail: PickupGameInviteDisplay?
    @State private var followingPendingPostCreateInviteGame: PickupGameRow?
    @State private var pickupInviteResponseInFlightId: UUID?
    @State private var followingMyPickupBanner: String?
    @State private var followingMyPickupDidScheduleExpiryRefresh = false
    @State private var selectedGoingMode: GoingParticipationMode = .venueGames
    @State private var selectedGoingVenueTab: GoingVenueTab = .games
    @State private var selectedGoingGamesTab: GoingGamesTab = .playing
    @State private var selectedBusinessProGameFilter: BusinessProGameFilter = .all
    @State private var cachedGoingVenueGameItems: [FollowingGoingDisplayItem] = []
    @State private var cachedPlayingGameCards: [PickupGameJoinRequestCardDisplay] = []
    @State private var goingTabPerf = GoingTabPerfState()
    @State private var followingHostingPickupLoadInFlight = false
    @State private var showFavoriteTeamsPicker = false

    private struct GoingTabPerfState {
        var cachedManualSavedProGamesForDisplay: [SavedProGame] = []
        var cachedFavoriteTeamProGamesForDisplay: [FavoriteTeamProGame] = []
        var firstPaintRecorded = false
        var backgroundRefreshInFlight = false
        var deferredWorkReady = false
        var screenAppearAt: CFAbsoluteTime?
        var lastVisibleSurfacePrepareAt: Date?
        var lastVisibleSurfacePrepareFingerprint: String?
        var lastBackgroundRefreshAt: Date?
        var deferredBackgroundRefreshTask: Task<Void, Never>?
        var deferredSurfacePrepareTask: Task<Void, Never>?
        var lastProGamesDisplayRebuildAt: Date?
        var proGamesDisplayRebuildTask: Task<Void, Never>?
        var proGamesDisplayRebuildInFlight = false
        var proGamesStatusIndicatorVisible = false
        var proGamesStatusIndicatorShowTask: Task<Void, Never>?
        var tabSelectionActivationGeneration: UInt64 = 0
        var tabSelectionActivationActive = false
        var handledTabSelectionActivationGeneration: UInt64 = 0
        static let visibleSurfacePrepareTTL: TimeInterval = 25
        static let backgroundRefreshTTL: TimeInterval = 25
        static let proGamesDisplayRebuildTTL: TimeInterval = 25
        static let deferredWorkDelayMs = 200
        static let deferredBackgroundRefreshDelayNs: UInt64 = 200_000_000
        static let proGamesStatusIndicatorMinVisibleDelayNs: UInt64 = 300_000_000
    }

    private let followingMyPickupMinuteTicker = Timer.publish(every: 60, on: .main, in: .common).autoconnect()

    /// Nil while Going tab is not selected so lazy mount does not trigger global refresh at launch.
    private var followingTabTaskIdentity: String? {
        guard isFollowingTabSelected else { return nil }
        return viewModel.currentUserAuthId?.uuidString ?? "signedOut"
    }

    private var favoriteTeamAutoFollowTaskIdentity: String? {
        guard isFollowingTabSelected, activeGoingMode == .proGames, !isBusinessProGamesOnly else { return nil }
        let auth = viewModel.currentUserAuthId?.uuidString ?? "signedOut"
        return [
            auth,
            proGamesAutoFollowFavoriteTeams ? "on" : "off",
            "\(proGamesFavoriteTeamWindowDays)",
            favoriteTeamIDsRaw
        ].joined(separator: "|")
    }

    private var businessFavoriteTeamProGamesTaskIdentity: String? {
        guard isFollowingTabSelected, activeGoingMode == .proGames, isBusinessProGamesOnly else { return nil }
        let auth = viewModel.currentUserAuthId?.uuidString ?? "signedOut"
        let businessId = viewModel.currentBusinessIdForAddLocation()?.uuidString ?? "noBusiness"
        let teams = viewModel.businessFavoriteTeamIDs.sorted().joined(separator: ",")
        return "\(auth)|\(businessId)|\(teams)"
    }

    private var isBusinessProGamesOnly: Bool {
        viewModel.hasAuthenticatedVenueOwnerSession
    }

    private var activeGoingMode: GoingParticipationMode {
        isBusinessProGamesOnly ? .proGames : selectedGoingMode
    }

    private var goingProNativeAdsHostVisible: Bool {
        isFollowingTabSelected && activeGoingMode == .proGames
    }

    private var goingProGamesAdPlan: GoingProGamesAdPlan {
        GoingProGamesAdPlacement.plan(
            savedGames: manualSavedProGamesForDisplay,
            favoriteTeamGames: proGamesAutoFollowFavoriteTeams ? favoriteTeamProGamesForDisplay : [],
            businessMyTeamSavedGames: businessMyTeamSavedProGamesForDisplay,
            businessMyTeamAutoGames: businessMyTeamProGamesForDisplay
        )
    }

    var body: some View {
        followingLifecycleRoot
    }

    private var followingLifecycleRoot: some View {
        attachFollowingPresentation(to: followingLifecycleCore)
    }

    private var followingLifecycleCore: some View {
        followingLifecycleEventHandlers
    }

    private var followingScreenShell: some View {
        followingRootContent
    }

    @ViewBuilder
    private var followingRootContent: some View {
        if isFollowingTabSelected {
            followingActiveContent
        } else {
            followingOffTabPlaceholder
        }
    }

    /// Preserved-tab shell: skip Going lists, cards, and avatar work while off-screen.
    private var followingOffTabPlaceholder: some View {
        Color.clear
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .accessibilityHidden(true)
    }

    private var followingActiveContent: some View {
        ZStack {
            Color.clear
                .fanGeoScreenBackground()
                .ignoresSafeArea()

            if viewModel.isAuthenticatedForSocialFeatures {
                loggedInContent
            } else {
                loggedOutContent
            }
        }
    }

    private var followingLifecycleEventHandlers: some View {
        followingLifecycleTabOnChange
    }

    private var followingLifecycleOnChanges: some View {
        followingLifecycleTasks
        .onChange(of: scenePhase) {
            handleFollowingScenePhaseChange(scenePhase)
        }
        .onChange(of: viewModel.isAuthenticatedForSocialFeatures) { _, _ in
            handleFollowingSocialAuthChange()
        }
        .onChange(of: viewModel.followingTabGoingItems.count) { _, _ in
            guard isFollowingTabSelected else { return }
            rebuildFollowingDisplayCaches(reason: "goingItemsChanged", prefetchAvatars: false)
        }
        .onChange(of: viewModel.myPickupGameJoinRequestCards) { _, _ in
            guard isFollowingTabSelected else { return }
            rebuildFollowingDisplayCaches(reason: "pickupJoinCardsChanged", prefetchAvatars: false)
        }
        .onChange(of: viewModel.savedProGames.count) { _, _ in
            guard isFollowingTabSelected else { return }
            scheduleGoingProGamesDisplayCacheRebuild(reason: "savedProGamesChanged")
        }
        .onChange(of: viewModel.favoriteTeamProGames.count) { _, _ in
            guard isFollowingTabSelected else { return }
            scheduleGoingProGamesDisplayCacheRebuild(reason: "favoriteTeamProGamesChanged")
        }
        .onChange(of: proGamesAutoFollowFavoriteTeams) { _, _ in
            guard isFollowingTabSelected else { return }
            scheduleGoingProGamesDisplayCacheRebuild(reason: "autoFollowToggled")
        }
        .onChange(of: clearedCompletedFavoriteTeamProGamesRaw) { _, _ in
            guard isFollowingTabSelected else { return }
            scheduleGoingProGamesDisplayCacheRebuild(reason: "clearedCompletedChanged")
        }
        .onChange(of: viewModel.incomingPickupGameInvites.count) { _, _ in
            guard isFollowingTabSelected else { return }
            prefetchVisibleGoingAvatars(reason: "incomingPickupInvitesChanged")
        }
        .onChange(of: viewModel.pendingProGameNotificationDeepLink) { _, request in
            guard let request else { return }
            pendingProGameNotificationMatchID = request.matchID
            selectedGoingMode = .proGames
            sanitizeBusinessGoingModeIfNeeded()
            viewModel.clearPendingProGameNotificationDeepLink()
            Task { await fulfillProGameNotificationDeepLinkIfReady() }
        }
    }

    private var followingLifecycleTabOnChange: some View {
        followingLifecycleOnChanges
        .onChange(of: isFollowingTabSelected) {
            handleFollowingTabSelectionChange(isFollowingTabSelected)
        }
    }

    private var followingLifecycleTasks: some View {
        followingLifecycleAuthOnChange
        .task(id: followingTabTaskIdentity) {
            guard isFollowingTabSelected else { return }
            guard viewModel.isAuthenticatedForSocialFeatures else { return }
            AppPerfDebug.screenLoadStart(tab: "following", source: "goingTabTask")
            _ = runGoingTabSelectionActivationIfNeeded(
                source: "goingTabTask",
                deferredRefreshReason: "goingTabActivation"
            )
        }
        .task(id: favoriteTeamAutoFollowTaskIdentity) {
            guard favoriteTeamAutoFollowTaskIdentity != nil else { return }
            await refreshFavoriteTeamProGames(reason: "autoFollowStateChanged")
        }
        .task(id: businessFavoriteTeamProGamesTaskIdentity) {
            guard businessFavoriteTeamProGamesTaskIdentity != nil else { return }
            await refreshBusinessFavoriteTeamProGames(reason: "businessFavoriteTeamsChanged")
        }
    }

    private var followingLifecycleAuthOnChange: some View {
        followingScreenShell
        .onAppear(perform: handleFollowingScreenAppear)
        .onChange(of: viewModel.currentUserAuthId) {
            handleFollowingAuthIdChange(viewModel.currentUserAuthId)
        }
    }

    private func handleFollowingScreenAppear() {
        if !isFollowingTabSelected {
            _ = paintGoingTabFromCachedStateImmediately(reason: "appear")
        }
        scheduleGoingProGamesDisplayCacheRebuild(reason: "appear")
        sanitizeBusinessGoingModeIfNeeded()
        if suppressInitialAutoRefresh && !didHandleInitialAutoRefresh {
            didHandleInitialAutoRefresh = true
            return
        }
        guard isFollowingTabSelected else { return }
        guard viewModel.isAuthenticatedForSocialFeatures else { return }
        _ = runGoingTabSelectionActivationIfNeeded(source: "onAppear")
    }

    private func handleFollowingAuthIdChange(_ newId: UUID?) {
        scheduleGoingProGamesDisplayCacheRebuild(reason: "authChanged")
        sanitizeBusinessGoingModeIfNeeded()
        guard isFollowingTabSelected else { return }
        if newId != nil {
            let cachedPaint = paintGoingTabFromCachedStateImmediately(reason: "authChanged")
            logGoingTabPerfSummary(
                cachedPaint: cachedPaint,
                deferredRefresh: !goingTabRecentlyBackgroundRefreshed(within: GoingTabPerfState.backgroundRefreshTTL),
                reason: "authChanged"
            )
            scheduleGoingTabDeferredSurfacePrepare(reason: "authChanged")
            scheduleGoingTabDeferredBackgroundRefresh(reason: "authChanged")
        } else {
            clearFollowingUserSpecificState()
            interestedOnlyEncoded = ""
        }
    }

    private func handleFollowingScenePhaseChange(_ phase: ScenePhase) {
        guard phase == .active, isFollowingTabSelected else { return }
        guard viewModel.isAuthenticatedForSocialFeatures, viewModel.canFanUsePickupGamesUI else { return }
        Task {
            await viewModel.loadMyPickupGameJoinRequestsForFollowing(reason: "foreground")
            await viewModel.loadIncomingPickupGameInvites()
        }
    }

    private func handleFollowingSocialAuthChange() {
        rebuildFollowingDisplayCaches(reason: "socialAuthChanged", prefetchAvatars: false)
        scheduleGoingProGamesDisplayCacheRebuild(reason: "socialAuthChanged")
        sanitizeBusinessGoingModeIfNeeded()
        Task { await syncFollowingAfterAuthChange() }
    }

    private func handleFollowingTabSelectionChange(_ visible: Bool) {
        if visible {
            AppPerfDebug.screenLoadStart(tab: "following", source: "tabVisible")
            prepareGoingTabSelectionGeneration()
            _ = runGoingTabSelectionActivationIfNeeded(source: "tabVisible")
            Task { @MainActor in
                await Task.yield()
                TabPerf.tabSwitchRendered(tab: "following")
                await fulfillProGameNotificationDeepLinkIfReady()
            }
        } else {
            goingTabPerf.firstPaintRecorded = false
            goingTabPerf.tabSelectionActivationActive = false
            goingTabPerf.handledTabSelectionActivationGeneration = 0
        }
    }

    /// Begins a new Going tab selection session (tab became visible).
    private func prepareGoingTabSelectionGeneration() {
        guard isFollowingTabSelected else { return }
        if !goingTabPerf.tabSelectionActivationActive {
            goingTabPerf.tabSelectionActivationGeneration &+= 1
            goingTabPerf.tabSelectionActivationActive = true
        }
    }

    /// Returns the current selection generation when this caller wins activation; nil if duplicate.
    private func claimGoingTabSelectionActivation(source: String) -> UInt64? {
        prepareGoingTabSelectionGeneration()
        let generation = goingTabPerf.tabSelectionActivationGeneration
        if goingTabPerf.handledTabSelectionActivationGeneration == generation {
            DebugLogGate.goingTabPerfVerbose("[GoingTabPerf] activationSkipped reason=duplicateGeneration")
            return nil
        }
        goingTabPerf.handledTabSelectionActivationGeneration = generation
        return generation
    }

    /// Standard tab-selection activation: cached paint + deferred surface prep + background refresh.
    @discardableResult
    private func runGoingTabSelectionActivationIfNeeded(
        source: String,
        deferredRefreshReason: String? = nil
    ) -> Bool {
        guard isFollowingTabSelected else { return false }
        guard viewModel.isAuthenticatedForSocialFeatures else { return false }
        guard claimGoingTabSelectionActivation(source: source) != nil else { return false }

        markGoingScreenAppear(source: source)
        let cachedPaint = paintGoingTabFromCachedStateImmediately(reason: source)
        if !cachedPaint {
            goingTabPerf.deferredWorkReady = false
            goingTabPerf.firstPaintRecorded = false
        }
        logGoingTabPerfSummary(
            cachedPaint: cachedPaint,
            deferredRefresh: !goingTabRecentlyBackgroundRefreshed(within: GoingTabPerfState.backgroundRefreshTTL),
            reason: source
        )
        scheduleGoingTabDeferredSurfacePrepare(reason: source)
        scheduleGoingTabDeferredBackgroundRefresh(reason: deferredRefreshReason ?? source)
        return true
    }

    private func goingTabRecentlyPrepared(within interval: TimeInterval) -> Bool {
        guard let last = goingTabPerf.lastVisibleSurfacePrepareAt else { return false }
        return Date().timeIntervalSince(last) < interval
    }

    private func goingTabRecentlyBackgroundRefreshed(within interval: TimeInterval) -> Bool {
        guard let last = goingTabPerf.lastBackgroundRefreshAt else { return false }
        return Date().timeIntervalSince(last) < interval
    }

    @discardableResult
    private func paintGoingTabFromCachedStateImmediately(reason: String) -> Bool {
        if viewModel.savedProGames.isEmpty, let userID = viewModel.currentUserAuthId {
            viewModel.reloadSavedProGamesFromStorage(for: userID)
        }
        rebuildFollowingDisplayCaches(reason: "\(reason):cachedPaint", prefetchAvatars: false)
        let hasCachedContent = goingTabHasCachedContentForImmediatePaint()
        if hasCachedContent {
            goingTabPerf.deferredWorkReady = true
            recordGoingFirstPaintIfNeeded(source: "\(reason)Cached")
        }
        return hasCachedContent
    }

    private func goingTabHasCachedContentForImmediatePaint() -> Bool {
        !viewModel.followingTabGoingItems.isEmpty
            || !goingTabPerf.cachedManualSavedProGamesForDisplay.isEmpty
            || !goingTabPerf.cachedFavoriteTeamProGamesForDisplay.isEmpty
            || !viewModel.savedProGames.isEmpty
            || !viewModel.favoriteTeamProGames.isEmpty
            || !viewModel.myPickupGameJoinRequestCards.isEmpty
            || !viewModel.myPickupGamesForSettings.isEmpty
            || !viewModel.incomingPickupGameInvites.isEmpty
    }

    private func logGoingTabPerfSummary(cachedPaint: Bool, deferredRefresh: Bool, reason: String) {
        DebugLogGate.goingTabPerfSummary(
            "[GoingTabPerf] cachedPaint=\(cachedPaint) " +
            "deferredRefresh=\(deferredRefresh) " +
            "delayMs=\(GoingTabPerfState.deferredWorkDelayMs) " +
            "reason=\(reason)"
        )
    }

    /// Stable snapshot of Going tab inputs that ``prepareGoingTabVisibleSurface`` rebuilds from.
    private func goingTabVisibleSurfaceDataFingerprint() -> String {
        let auth = viewModel.currentUserAuthId?.uuidString ?? "signedOut"
        let going = viewModel.followingTabGoingItems
            .map { "\($0.id.uuidString):\($0.isServerGoing ? 1 : 0):\($0.isInterestedOnlyLocal ? 1 : 0)" }
            .sorted()
            .joined(separator: ",")
        let saved = viewModel.savedProGames.map(\.id).sorted().joined(separator: ",")
        let favorite = viewModel.favoriteTeamProGames.map(\.id).sorted().joined(separator: ",")
        let playing = viewModel.myPickupGameJoinRequestCards
            .map { "\($0.id.uuidString):\($0.pill.rawValue)" }
            .sorted()
            .joined(separator: ",")
        let hosting = (
            viewModel.myPickupGamesForSettings.map(\.id.uuidString)
            + viewModel.myRemovedPickupGamesForSettings.map(\.id.uuidString)
        ).sorted().joined(separator: ",")
        let invites = viewModel.incomingPickupGameInvites
            .map(\.id.uuidString)
            .sorted()
            .joined(separator: ",")
        let prefs = [
            proGamesAutoFollowFavoriteTeams ? "autoOn" : "autoOff",
            "\(proGamesFavoriteTeamWindowDays)",
            favoriteTeamIDsRaw
        ].joined(separator: "|")
        return [
            "auth=\(auth)",
            "going=\(going)",
            "saved=\(saved)",
            "favorite=\(favorite)",
            "playing=\(playing)",
            "hosting=\(hosting)",
            "invites=\(invites)",
            "prefs=\(prefs)"
        ].joined(separator: ";")
    }

    private func scheduleGoingTabDeferredSurfacePrepare(reason: String) {
        let fingerprint = goingTabVisibleSurfaceDataFingerprint()
        if goingTabRecentlyPrepared(within: GoingTabPerfState.visibleSurfacePrepareTTL),
           goingTabPerf.lastVisibleSurfacePrepareFingerprint == fingerprint {
            TabPerf.refreshSkipped(name: "goingTabVisibleSurface", reason: "freshUnchangedFingerprint")
            DebugLogGate.goingTabPerfVerbose(
                "[GoingTabPerf] surfacePrepareSkipped reason=freshUnchangedFingerprint"
            )
            return
        }
        if goingTabPerf.deferredSurfacePrepareTask != nil {
            TabPerf.duplicateRefreshCoalesced(name: "goingTabVisibleSurface")
            return
        }
        goingTabPerf.deferredSurfacePrepareTask = Task { @MainActor in
            await Task.yield()
            try? await Task.sleep(nanoseconds: GoingTabPerfState.deferredBackgroundRefreshDelayNs)
            guard !Task.isCancelled else { return }
            guard isFollowingTabSelected else { return }
            await prepareGoingTabVisibleSurface(reason: reason)
            goingTabPerf.deferredSurfacePrepareTask = nil
        }
    }

    private func scheduleGoingTabDeferredBackgroundRefresh(reason: String) {
        if goingTabRecentlyBackgroundRefreshed(within: GoingTabPerfState.backgroundRefreshTTL) {
            TabPerf.refreshSkipped(name: "goingTabBackgroundRefresh", reason: "freshCache")
            GoingPerfDebug.duplicateRefreshSkipped(source: reason, reason: "freshCache")
            DebugLogGate.tabSwitchPerfVerbose("[TabDeferredRefresh] tab=going reason=\(reason) skipped=fresh")
            return
        }
        if goingTabPerf.backgroundRefreshInFlight {
            TabPerf.duplicateRefreshCoalesced(name: "goingTabBackgroundRefresh")
            GoingPerfDebug.duplicateRefreshSkipped(source: reason, reason: "inFlight")
            DebugLogGate.tabSwitchPerfVerbose("[TabDeferredRefresh] tab=going reason=\(reason) skipped=inFlight")
            return
        }
        if goingTabPerf.deferredBackgroundRefreshTask != nil {
            TabPerf.duplicateRefreshCoalesced(name: "goingTabBackgroundRefresh")
            GoingPerfDebug.duplicateRefreshSkipped(source: reason, reason: "deferredScheduled")
            DebugLogGate.tabSwitchPerfVerbose("[TabDeferredRefresh] tab=going reason=\(reason) skipped=deferredScheduled")
            return
        }
        goingTabPerf.deferredBackgroundRefreshTask = Task { @MainActor in
            await Task.yield()
            try? await Task.sleep(nanoseconds: GoingTabPerfState.deferredBackgroundRefreshDelayNs)
            guard !Task.isCancelled else { return }
            guard isFollowingTabSelected else { return }
            DebugLogGate.tabSwitchPerfVerbose("[TabDeferredRefresh] tab=going reason=\(reason) started")
            await performGoingTabBackgroundRefresh(reason: reason)
            goingTabPerf.lastBackgroundRefreshAt = Date()
            DebugLogGate.tabSwitchPerfVerbose("[TabDeferredRefresh] tab=going reason=\(reason) finished")
            goingTabPerf.deferredBackgroundRefreshTask = nil
        }
    }

    @MainActor
    private func fulfillProGameNotificationDeepLinkIfReady() async {
        guard isFollowingTabSelected else { return }
        guard let matchID = pendingProGameNotificationMatchID else { return }

        selectedGoingMode = .proGames
        sanitizeBusinessGoingModeIfNeeded()

        await prepareGoingTabVisibleSurface(reason: "proGameNotificationDeepLink")
        await performGoingTabBackgroundRefresh(reason: "proGameNotificationDeepLink")
        await viewModel.refreshLiveMatchesForLiveTab(forceRefresh: false)

        if let match = viewModel.resolveLiveMatchForProGameNotificationDeepLink(matchID: matchID) {
            proGameMatchDetailSelection = match
        }

        pendingProGameNotificationMatchID = nil
    }

    @ViewBuilder
    private func attachFollowingPresentation<Content: View>(to content: Content) -> some View {
        content
        .sheet(item: $pickupDetailNav, onDismiss: {
            Task {
                await viewModel.loadMyPickupGameJoinRequestsForFollowing(
                    forceRefresh: true,
                    reason: "pickupDetailDismiss"
                )
            }
        }) { token in
            DiscoverPickupGameDetailSheet(viewModel: viewModel, gameId: token.id)
        }
        .alert(item: $followingPickupWithdrawConfirm) { state in
            Alert(
                title: Text(state.intent.alertTitle),
                message: Text(state.intent.alertMessage),
                primaryButton: .destructive(Text("Yes, withdraw")) {
                    Task { await performFollowingPickupWithdraw(state) }
                },
                secondaryButton: .cancel()
            )
        }
        .sheet(item: $followingMyPickupFormMode) { mode in
            NavigationStack {
                SettingsPickupGameFormView(
                    viewModel: viewModel,
                    mode: mode,
                    onCreated: { row in
                        followingPendingPostCreateInviteGame = row
                    }
                ) {
                    followingMyPickupFormMode = nil
                    Task {
                        await viewModel.loadMyPickupGamesForSettings(forceRefresh: true, reason: "followingFormDismiss")
                        await viewModel.refreshPickupGamesForDiscoverMap(force: true)
                        logFollowingMyPickupGames(action: "formDismissReload")
                    }
                }
            }
        }
        .onChange(of: followingMyPickupFormMode) { _, newValue in
            guard newValue == nil, let row = followingPendingPostCreateInviteGame else { return }
            followingPendingPostCreateInviteGame = nil
            followingPickupInviteGame = row
        }
        .sheet(item: $followingPickupInviteGame, onDismiss: {
            Task {
                await viewModel.loadIncomingPickupGameInvites()
                await viewModel.loadMyPickupGamesForSettings()
            }
        }) { game in
            PickupGameInviteFriendsSheet(viewModel: viewModel, game: game)
                .environmentObject(chatViewModel)
        }
        .sheet(item: $followingPickupInviteDetail) { item in
            PickupGameInviteDetailSheet(
                item: item,
                isResponding: pickupInviteResponseInFlightId == item.id,
                onRespond: { status in
                    await respondToPickupInvite(item, status: status)
                    followingPickupInviteDetail = nil
                }
            )
        }
        .sheet(item: $followingMyPickupOrganizerRequestsGame, onDismiss: {
            Task {
                await viewModel.loadMyPickupGamesForSettings()
                logFollowingMyPickupGames(action: "requestsSheetDismiss")
            }
        }) { game in
            PickupOrganizerRequestsSheet(viewModel: viewModel, game: game)
        }
        .sheet(item: $followingMyPickupDetailGame, onDismiss: {
            Task {
                await viewModel.loadMyPickupGamesForSettings()
                logFollowingMyPickupGames(action: "detailSheetDismiss")
            }
        }) { game in
            FollowingMyPickupHostedGameDetailSheet(
                viewModel: viewModel,
                game: game,
                now: followingMyPickupClockTick,
                colorScheme: followingColorScheme,
                onDone: { followingMyPickupDetailGame = nil },
                onEdit: {
                    followingMyPickupDetailGame = nil
                    followingMyPickupFormMode = .edit(game)
                },
                onDelete: {
                    followingMyPickupDetailGame = nil
                    followingMyPickupDeleteTarget = game
                },
                onManageRequests: {
                    followingMyPickupDetailGame = nil
                    followingMyPickupOrganizerRequestsGame = game
                },
                onInvite: {
                    followingMyPickupDetailGame = nil
                    followingPickupInviteGame = game
                }
            )
            .environmentObject(chatViewModel)
        }
        .sheet(item: $proGamePredictionSheet) { context in
            ProGamePredictionSheet(viewModel: viewModel, game: context.game)
        }
        .sheet(item: $proGameMatchDetailSelection) { match in
            LiveMatchDetailSheet(match: match)
        }
        .sheet(isPresented: $showFavoriteTeamsPicker) {
            FavoriteTeamsPickerSheet(
                selectedIDs: Binding(
                    get: { Set(FavoriteTeamsStore.decodeIDs(from: favoriteTeamIDsRaw)) },
                    set: { newSet in
                        let sorted = Array(newSet).sorted()
                        favoriteTeamIDsRaw = FavoriteTeamsStore.encodeIDs(sorted)
                        Task {
                            await viewModel.syncFavoriteTeamsToSupabase(teamIDs: sorted)
                        }
                    }
                )
            )
        }
        .alert(followingMyPickupDeleteAlertTitle, isPresented: Binding(
            get: { followingMyPickupDeleteTarget != nil },
            set: { if !$0 { followingMyPickupDeleteTarget = nil } }
        )) {
            Button("Keep game", role: .cancel) { followingMyPickupDeleteTarget = nil }
            Button(followingMyPickupDeleteButtonTitle, role: .destructive) {
                guard let row = followingMyPickupDeleteTarget else { return }
                followingMyPickupDeleteTarget = nil
                Task { await performFollowingMyPickupDelete(row) }
            }
        } message: {
            Text(followingMyPickupDeleteAlertMessage)
        }
        .overlay(alignment: .bottom) {
            if let text = followingMyPickupBanner, !text.isEmpty {
                Text(text)
                    .font(FGTypography.caption)
                    .foregroundStyle(FGColor.primaryText(followingColorScheme))
                    .padding(.horizontal, FGSpacing.md)
                    .padding(.vertical, FGSpacing.sm)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .padding()
            }
        }
    }

    /// Reload Following when fan or business-owner auth changes while a Supabase session may already exist.
    private func syncFollowingAfterAuthChange() async {
        if viewModel.isAuthenticatedForSocialFeatures, isBusinessProGamesOnly {
            let cachedPaint = paintGoingTabFromCachedStateImmediately(reason: "authChanged")
            logGoingTabPerfSummary(
                cachedPaint: cachedPaint,
                deferredRefresh: !goingTabRecentlyBackgroundRefreshed(within: GoingTabPerfState.backgroundRefreshTTL),
                reason: "authChanged"
            )
            scheduleGoingTabDeferredSurfacePrepare(reason: "authChanged")
            scheduleGoingTabDeferredBackgroundRefresh(reason: "authChanged")
        } else if viewModel.isAuthenticatedForSocialFeatures, viewModel.canUseFollowingTab {
            let cachedPaint = paintGoingTabFromCachedStateImmediately(reason: "authChanged")
            logGoingTabPerfSummary(
                cachedPaint: cachedPaint,
                deferredRefresh: !goingTabRecentlyBackgroundRefreshed(within: GoingTabPerfState.backgroundRefreshTTL),
                reason: "authChanged"
            )
            scheduleGoingTabDeferredSurfacePrepare(reason: "authChanged")
            scheduleGoingTabDeferredBackgroundRefresh(reason: "authChanged")
        } else {
            clearFollowingUserSpecificState()
            interestedOnlyEncoded = ""
        }
    }

    private func sanitizeBusinessGoingModeIfNeeded() {
        guard isBusinessProGamesOnly, selectedGoingMode != .proGames else { return }
        selectedGoingMode = .proGames
    }

    private func performFollowingPickupWithdraw(_ state: PickupJoinWithdrawConfirmState) async {
        followingPickupWithdrawInFlight = true
        followingPickupWithdrawConfirm = nil
        defer { followingPickupWithdrawInFlight = false }
        do {
            try await viewModel.withdrawMyPickupJoinRequest(requestId: state.requestId, pickupGameId: state.pickupGameId)
        } catch {
            viewModel.showSocialActionToast(error.localizedDescription, isError: true)
        }
    }

    private var followingMyPickupDeleteTargetIsExpired: Bool {
        guard let row = followingMyPickupDeleteTarget,
              let deadline = row.pickupHistoryClientCleanupDeadline() else {
            return false
        }
        return followingMyPickupClockTick >= deadline
    }

    private var followingMyPickupDeleteAlertTitle: String {
        followingMyPickupDeleteTargetIsExpired ? "Clear expired pickup game?" : "Cancel this pickup game?"
    }

    private var followingMyPickupDeleteButtonTitle: String {
        followingMyPickupDeleteTargetIsExpired ? "Clear expired" : "Cancel game"
    }

    private var followingMyPickupDeleteAlertMessage: String {
        followingMyPickupDeleteTargetIsExpired
            ? "This removes the expired hosted pickup game from your active Hosting list."
            : "Players who requested or joined will be notified."
    }

    // MARK: - Logged out

    private var loggedOutContent: some View {
        AuthenticationRequiredView.going
            .padding(.bottom, 92)
    }

    // MARK: - Logged in

    private var loggedInContent: some View {
        VStack(alignment: .leading, spacing: 0) {
            goingHubHeader
            .padding(.horizontal, FGSpacing.md)
            .padding(.bottom, 8)

            ScrollView {
                goingHubContent
                    .padding(.horizontal, FGSpacing.md)
                    .padding(.bottom, 110)
            }
            .refreshable {
                if isBusinessProGamesOnly {
                    await reloadBusinessProGamesData(reason: "pullToRefresh")
                    logGoingHubDebug(reason: "pullToRefresh")
                    return
                }
                if activeGoingMode == .proGames {
                    await viewModel.refreshGoingProGames(reason: "pullToRefresh")
                    await refreshFavoriteTeamProGames(reason: "pullToRefresh", forceRefresh: true)
                } else {
                    await viewModel.fetchSavedProGames(forceRefresh: true, reason: "pullToRefresh")
                }
                await viewModel.refreshFollowingTabDataGlobally()
                await viewModel.loadMyPickupGameJoinRequestsForFollowing(
                    forceRefresh: true,
                    reason: "pullToRefresh"
                )
                logFollowingMyPickupGames(action: "pullToRefresh")
                logGoingHubDebug(reason: "pullToRefresh")
            }
            .onReceive(followingMyPickupMinuteTicker) { date in
                followingMyPickupClockTick = date
                scheduleFollowingMyPickupExpiryRefreshIfNeeded(now: date)
                guard isFollowingTabSelected else { return }
                rebuildFollowingDisplayCaches(reason: "goingCompletedVisibilityTick", prefetchAvatars: false)
                scheduleGoingProGamesDisplayCacheRebuild(reason: "goingCompletedVisibilityTick")
            }
        }
        .onAppear {
            logGoingHubDebug(reason: "appear")
        }
    }

    private var goingHubHeader: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                FanGeoPagePurposeHeader(
                    title: "Going",
                    subtitle: goingHubHeaderSubtitle
                )
                .padding(.top, 8)

                Spacer(minLength: 8)

                if !isBusinessProGamesOnly {
                    goingInviteBellButton
                }
            }

            if let favoriteActionBanner {
                Text(favoriteActionBanner)
                    .font(FGTypography.metadata)
                    .fontWeight(.semibold)
                    .foregroundStyle(FGColor.accentYellow)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(10)
                    .background(FGColor.accentYellow.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: FGRadius.small, style: .continuous))
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }

            if !isBusinessProGamesOnly && goingHubShouldShowActivityStrip {
                goingHubActivityStrip
            }
        }
    }

    private var goingHubHeaderSubtitle: String {
        if isBusinessProGamesOnly {
            return "Saved live and scheduled pro games for your business account."
        }
        return "Games, venues, and pickup plans you're part of."
    }

    private var goingInviteBellButton: some View {
        let count = viewModel.incomingPickupGameInvites.count
        return Button {
            selectedGoingMode = .pickupGames
            selectedGoingGamesTab = .invites
        } label: {
            ZStack(alignment: .topTrailing) {
                Image(systemName: "bell")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(FGColor.primaryText(followingColorScheme))
                    .frame(width: 38, height: 38)
                    .background(.ultraThinMaterial, in: Circle())
                    .overlay(
                        Circle()
                            .strokeBorder(FGColor.divider(followingColorScheme).opacity(0.7), lineWidth: 1)
                    )

                if count > 0 {
                    Text(count > 9 ? "9+" : "\(count)")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(minWidth: 16, minHeight: 16)
                        .padding(.horizontal, count > 9 ? 3 : 0)
                        .background(Color.red.opacity(0.95), in: Capsule())
                        .offset(x: 3, y: -2)
                        .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(count > 0 ? "\(count) pickup game invites" : "Pickup game invites")
        .animation(.spring(response: 0.28, dampingFraction: 0.82), value: count)
    }

    private var goingHubContent: some View {
        VStack(alignment: .leading, spacing: 22) {
            goingModeSwitcher

            Group {
                switch activeGoingMode {
                case .venueGames:
                    goingVenueTabsGroup
                case .pickupGames:
                    goingGamesTabsGroup
                case .proGames:
                    goingProGamesGroup
                }
            }
            .id(activeGoingMode)
            .transition(.opacity.combined(with: .move(edge: .trailing)))
        }
        .padding(.top, 6)
    }

    private var goingVenueGameItems: [FollowingGoingDisplayItem] {
        cachedGoingVenueGameItems
    }

    private func rebuildFollowingDisplayCaches(reason: String, prefetchAvatars: Bool = true) {
#if DEBUG
        let started = CFAbsoluteTimeGetCurrent()
#endif
        let sorted = MapViewModel.sortFollowingGoingItemsChronologically(
            viewModel.followingTabGoingItems
                .filter(\.isActiveGoingTabPlan)
                .filter { GoingTabCompletedGameVisibility.isVenueGameVisibleInGoingTab(row: $0.venueEvent) }
        )
        cachedGoingVenueGameItems = sorted
        cachedPlayingGameCards = viewModel.myPickupGameJoinRequestCards.filter { card in
            switch card.pill {
            case .pending, .approved, .declined:
                return true
            case .cancelled, .withdrawing, .canceledByOrganizer:
                return false
            }
        }.filter { card in
            guard let game = viewModel.pickupGamesFollowingTabCache[card.pickupGameId] else { return true }
            return GoingTabCompletedGameVisibility.isPickupGameVisibleInGoingTab(row: game)
        }
        logGoingTabSortDebug(sorted)
        if prefetchAvatars {
            prefetchVisibleGoingAvatars(reason: reason)
        }
#if DEBUG
        let ms = (CFAbsoluteTimeGetCurrent() - started) * 1000
        DebugLogGate.goingTabPerfVerbose(
            "[RenderPerf] view=FollowingScreen renderMs=\(String(format: "%.2f", ms)) rebuildReason=\(reason)"
        )
        DebugLogGate.goingTabPerfVerbose(
            "[PickupPlayingDebug] visiblePlayingCount=\(cachedPlayingGameCards.count)"
        )
#endif
    }

    private func prefetchVisibleGoingAvatars(reason: String) {
        var seen = Set<URL>()
        var urls: [URL] = []

        func appendURL(thumbnail: String?, full: String?, refreshToken: UUID) {
            guard let raw = ImageDisplayURL.forListDisplay(
                thumbnail: thumbnail,
                full: full ?? "",
                refreshToken: refreshToken
            ),
                  let url = URL(string: raw),
                  seen.insert(url).inserted else { return }
            urls.append(url)
        }

        for card in cachedPlayingGameCards.prefix(10) {
            appendURL(
                thumbnail: viewModel.pickupOrganizerAvatarThumbnailForDetail(userId: card.organizerUserId),
                full: viewModel.pickupOrganizerAvatarFullForDetail(userId: card.organizerUserId),
                refreshToken: viewModel.pickupOrganizerAvatarRefreshTokenForDetail(userId: card.organizerUserId)
            )
        }

        for item in viewModel.incomingPickupGameInvites.prefix(6) {
            appendURL(
                thumbnail: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_thumbnail_url),
                full: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_url),
                refreshToken: UserAvatarView.stableRefreshToken(
                    userId: item.invite.inviter_user_id,
                    thumbnailURL: item.inviterProfile?.avatar_thumbnail_url,
                    avatarURL: item.inviterProfile?.avatar_url
                )
            )
        }

        guard !urls.isEmpty else {
#if DEBUG
            print("[SmoothPerf] operation=goingAvatarPrefetch skipped=noURLs durationMs=0 coalesced=false avatarCount=0 reason=\(reason)")
#endif
            return
        }

        Task {
            let startedAt = Date()
            await DiscoverMapImageCache.shared.prefetch(urls: urls, bucket: .avatar)
#if DEBUG
            let ms = Int(Date().timeIntervalSince(startedAt) * 1000)
            print("[SmoothPerf] operation=goingAvatarPrefetch skipped=none durationMs=\(ms) coalesced=false avatarCount=\(urls.count) reason=\(reason)")
#endif
        }
    }

    private func logGoingTabSortDebug(_ items: [FollowingGoingDisplayItem]) {
#if DEBUG
        let firstStart = items.first.map { goingTabSortDebugStartString(for: $0.venueEvent) } ?? "nil"
        print("[GoingTabSortDebug] count=\(items.count) firstStart=\(firstStart)")
#endif
    }

    private func goingTabSortDebugStartString(for row: VenueEventRow) -> String {
        if let raw = row.scheduled_start_at?.trimmingCharacters(in: .whitespacesAndNewlines),
           !raw.isEmpty {
            return raw
        }
        let date = row.event_date?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let time = row.event_time?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let combined = [date, time].filter { !$0.isEmpty }.joined(separator: " ")
        return combined.isEmpty ? "nil" : combined
    }

    private func watchingVenueGameIsCompleted(_ item: FollowingGoingDisplayItem) -> Bool {
        let completed = VenueGameExpiration.isWatchingCompleted(row: item.venueEvent)
#if DEBUG
        if completed, WatchingExpiredVenueGameDiagnostics.enabled {
            VenueGameExpiration.logAuditOncePerEvaluation(row: item.venueEvent, eventID: item.id)
            print("[WatchingExpiredVenueGame] detected event_id=\(item.id.uuidString.lowercased())")
        }
#endif
        return completed
    }

    private var goingModeSwitcher: some View {
        GameOnSegmentedControl(
            tabs: goingModeTabs,
            selection: $selectedGoingMode
        )
    }

    private var goingModeTabs: [GameOnSegmentedTab<GoingParticipationMode>] {
        let proGames = GameOnSegmentedTab(
            id: GoingParticipationMode.proGames,
            title: GoingParticipationMode.proGames.title,
            systemImage: GoingParticipationMode.proGames.systemImage,
            badge: savedProGamesTabBadge,
            tint: FGColor.accentGreen,
            accessibilityLabel: "Saved pro games"
        )
        if isBusinessProGamesOnly {
            return [proGames]
        }
        return [
            GameOnSegmentedTab(
                id: GoingParticipationMode.venueGames,
                title: GoingParticipationMode.venueGames.title,
                systemImage: GoingParticipationMode.venueGames.systemImage,
                badge: venueGamesTabBadge,
                tint: FGColor.accentGreen,
                accessibilityLabel: "Venue-hosted games"
            ),
            GameOnSegmentedTab(
                id: GoingParticipationMode.pickupGames,
                title: GoingParticipationMode.pickupGames.title,
                systemImage: GoingParticipationMode.pickupGames.systemImage,
                badge: pickupGamesTabBadge,
                tint: FGColor.accentGreen,
                showsActivityDot: viewModel.pendingPickupGameJoinRequestCount > 0 || !viewModel.incomingPickupGameInvites.isEmpty,
                accessibilityLabel: "Pickup and community games",
                activityAccessibilityLabel: "Pickup activity waiting"
            ),
            proGames
        ]
    }

    private var goingVenueTabsGroup: some View {
        goingTabbedPanel(title: "Venue Games", subtitle: "Venue-hosted games, sports bars, saved venues, and friends going later.") {
            GameOnSegmentedControl(
                tabs: [
                    GameOnSegmentedTab(id: GoingVenueTab.games, title: "I’m Going", systemImage: "checkmark.circle.fill", tint: FGColor.accentGreen, accessibilityLabel: "I’m Going venue games"),
                    GameOnSegmentedTab(id: GoingVenueTab.saved, title: "Saved", systemImage: "heart.fill", tint: FGColor.accentGreen)
                ],
                selection: $selectedGoingVenueTab
            )
        } content: {
            Group {
                switch selectedGoingVenueTab {
                case .games:
                    venueGamesTabContent
                case .saved:
                    savedVenuesTabContent
                }
            }
            .id(selectedGoingVenueTab)
            .transition(.opacity.combined(with: .move(edge: .trailing)))
        }
        .onAppear {
#if DEBUG
            print("[GoingTabDebug] renamedWatchingTabToImGoing=true")
            print("[GoingTabDebug] imGoingTabVisible=true")
#endif
        }
    }

    private var goingGamesTabsGroup: some View {
        goingTabbedPanel(title: "Pickup Games", subtitle: "Pickup, practice, and scrimmage activity.") {
            GameOnSegmentedControl(
                tabs: [
                    GameOnSegmentedTab(id: GoingGamesTab.playing, title: "Playing", badge: pickupPlayingTabBadge, tint: FGColor.accentGreen),
                    GameOnSegmentedTab(id: GoingGamesTab.hosting, title: "Hosting", badge: pickupHostingTabBadge, tint: Color.orange),
                    GameOnSegmentedTab(id: GoingGamesTab.invites, title: "Invites", badge: pickupInvitesTabBadge, tint: FGColor.accentBlue)
                ],
                selection: $selectedGoingGamesTab
            )
        } content: {
            Group {
                switch selectedGoingGamesTab {
                case .playing:
                    playingGamesContent
                case .hosting:
                    hostingGamesContent
                case .invites:
                    invitesGamesContent
                }
            }
            .id(selectedGoingGamesTab)
            .transition(.opacity.combined(with: .move(edge: .trailing)))
        }
    }

    private var goingProGamesGroup: some View {
        goingTabbedPanel(title: "Pro Games", subtitle: proGamesPanelSubtitle) {
            if isBusinessProGamesOnly {
                businessProGamesFilterControl
            } else {
                EmptyView()
            }
        } content: {
            VStack(alignment: .leading, spacing: 10) {
                goingProGamesUpdatingStatusBanner
                savedProGamesContent
            }
            .animation(.easeInOut(duration: 0.2), value: goingTabPerf.proGamesStatusIndicatorVisible)
        }
    }

    private var goingProGamesBackgroundWorkActive: Bool {
        guard activeGoingMode == .proGames else { return false }
        return goingTabPerf.backgroundRefreshInFlight || goingTabPerf.proGamesDisplayRebuildInFlight
    }

    private var goingProGamesStatusIndicatorMessage: String {
        goingTabPerf.backgroundRefreshInFlight
            ? "Refreshing schedule…"
            : "Updating games…"
    }

    private func syncGoingProGamesStatusIndicator() {
        if goingProGamesBackgroundWorkActive {
            guard goingTabPerf.proGamesStatusIndicatorShowTask == nil else { return }
            goingTabPerf.proGamesStatusIndicatorShowTask = Task { @MainActor in
                try? await Task.sleep(nanoseconds: GoingTabPerfState.proGamesStatusIndicatorMinVisibleDelayNs)
                guard !Task.isCancelled else { return }
                guard goingProGamesBackgroundWorkActive else {
                    goingTabPerf.proGamesStatusIndicatorShowTask = nil
                    return
                }
                goingTabPerf.proGamesStatusIndicatorVisible = true
                goingTabPerf.proGamesStatusIndicatorShowTask = nil
            }
        } else {
            goingTabPerf.proGamesStatusIndicatorShowTask?.cancel()
            goingTabPerf.proGamesStatusIndicatorShowTask = nil
            goingTabPerf.proGamesStatusIndicatorVisible = false
        }
    }

    @ViewBuilder
    private var goingProGamesUpdatingStatusBanner: some View {
        if goingTabPerf.proGamesStatusIndicatorVisible {
            HStack(spacing: 8) {
                ProgressView()
                    .controlSize(.small)
                Text(goingProGamesStatusIndicatorMessage)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(
                Capsule(style: .continuous)
                    .fill(Color(.secondarySystemGroupedBackground))
            )
            .overlay {
                Capsule(style: .continuous)
                    .strokeBorder(Color.primary.opacity(0.06), lineWidth: 1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .transition(.opacity.combined(with: .move(edge: .top)))
            .accessibilityElement(children: .combine)
            .accessibilityLabel(goingProGamesStatusIndicatorMessage)
        }
    }

    private var proGamesPanelSubtitle: String {
        isBusinessProGamesOnly
            ? "Saved pro games and followed-team matches for your business."
            : "Saved and favorite-team pro games to watch later."
    }

    @ViewBuilder
    private var savedProGamesContent: some View {
        if isBusinessProGamesOnly {
            businessProGamesContent
        } else {
            fanSavedProGamesContent
        }
    }

    private var fanSavedProGamesContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 10) {
                sectionEyebrow("Saved Games")
                goingSavedProGamesCompletedVisibilityNote
                if manualSavedProGamesForDisplay.isEmpty {
                    goingRichEmptyCard(
                        title: "📺 No saved pro games",
                        description: "Save live or upcoming games to follow them here.",
                        buttonTitle: "Browse Pro Games",
                        buttonAction: openCalendarProGamesFromGoing
                    )
                } else {
                    VStack(spacing: 12) {
                        ForEach(goingProGamesAdPlan.savedGamesItems) { item in
                            switch item {
                            case .game(let game):
                                savedProGameCard(game, badges: savedProGameBadges(for: game))
                            case .nativeAd(let slot):
                                goingNativeAdRow(slot: slot)
                            }
                        }
                    }
                }
            }

            VStack(alignment: .leading, spacing: 10) {
                sectionEyebrow("Favorite Team Games")
                favoriteTeamAlertsToggleRow
                if proGamesAutoFollowFavoriteTeams {
                    if favoriteTeamProGamesForDisplay.isEmpty {
                        goingRichEmptyCard(
                            title: "⭐ No favorite teams selected",
                            description: "Follow your favorite teams to receive kickoff, goal, and final-score alerts.",
                            buttonTitle: "Add Favorite Teams",
                            buttonAction: { showFavoriteTeamsPicker = true }
                        )
                    } else {
                        VStack(spacing: 12) {
                            ForEach(goingProGamesAdPlan.favoriteTeamItems) { item in
                                switch item {
                                case .game(let autoGame):
                                    savedProGameCard(
                                        autoGame.game,
                                        badges: favoriteTeamProGameBadges(),
                                        showsUnsaveButton: false,
                                        showsScoreUpdatesControl: true,
                                        favoriteTeamAlertItem: autoGame,
                                        onClearCompleted: {
                                            clearCompletedFavoriteTeamProGame(autoGame.game, scope: "fan")
                                        }
                                    )
                                case .nativeAd(let slot):
                                    goingNativeAdRow(slot: slot)
                                }
                            }
                        }
                    }
                } else {
                    goingRichEmptyCard(
                        title: "⭐ No favorite teams selected",
                        description: "Follow your favorite teams to receive kickoff, goal, and final-score alerts.",
                        buttonTitle: "Add Favorite Teams",
                        buttonAction: { showFavoriteTeamsPicker = true }
                    )
                }
            }
        }
        .padding(.top, 6)
        .task(id: manualSavedProGamesForDisplay.map(\.stableKey).joined(separator: "|")) {
            guard goingTabPerf.deferredWorkReady || isFollowingTabSelected else { return }
            await Task.yield()
            try? await Task.sleep(nanoseconds: 50_000_000)
            guard !Task.isCancelled else { return }
            GoingPerfDebug.deferredWork("predictionVoteSummaries", source: "fanSavedProGamesContent")
            await viewModel.prefetchProGamePredictionSummaries(for: manualSavedProGamesForDisplay)
        }
    }

    private var businessProGamesContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if selectedBusinessProGameFilter == .all {
                businessSavedProGamesSection
                businessMyTeamsProGamesSection
            } else {
                businessMyTeamsFilteredSection
            }
        }
        .padding(.top, 6)
    }

    private var businessSavedProGamesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionEyebrow("Saved Games")
            goingSavedProGamesCompletedVisibilityNote
            if manualSavedProGamesForDisplay.isEmpty {
                emptyCard(
                    icon: "heart",
                    title: "No saved pro games yet.",
                    subtitle: "Save pro games you want your business to track."
                )
            } else {
                VStack(spacing: 12) {
                    ForEach(goingProGamesAdPlan.savedGamesItems) { item in
                        switch item {
                        case .game(let game):
                            savedProGameCard(game, badges: businessSavedProGameBadges(for: game))
                        case .nativeAd(let slot):
                            goingNativeAdRow(slot: slot)
                        }
                    }
                }
            }
        }
    }

    private var businessMyTeamsProGamesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionEyebrow("My Teams")
            businessMyTeamsProGameList(emptyTitle: "No upcoming pro games found for your followed teams.")
        }
    }

    private var businessMyTeamsFilteredSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionEyebrow("My Teams")
            businessMyTeamsProGameList(emptyTitle: "No My Teams pro games match right now.")
        }
    }

    @ViewBuilder
    private func businessMyTeamsProGameList(emptyTitle: String) -> some View {
        if viewModel.businessFavoriteTeamIDs.isEmpty {
            emptyCard(
                icon: "star",
                title: "No business favorite teams yet.",
                subtitle: "Add Favorite Teams from the Business Dashboard to use My Teams."
            )
        } else if businessMyTeamSavedProGamesForDisplay.isEmpty && businessMyTeamProGamesForDisplay.isEmpty {
            emptyCard(
                icon: "star",
                title: emptyTitle,
                subtitle: "Try adding more teams from the Business Dashboard."
            )
        } else {
            VStack(spacing: 12) {
                ForEach(goingProGamesAdPlan.businessMyTeamsItems) { item in
                    switch item {
                    case .savedGame(let game):
                        savedProGameCard(game, badges: businessSavedProGameBadges(for: game))
                    case .autoGame(let autoGame):
                        savedProGameCard(
                            autoGame.game,
                            badges: businessMyTeamProGameBadges(),
                            showsUnsaveButton: false,
                            showsScoreUpdatesControl: true,
                            favoriteTeamAlertItem: autoGame,
                            onClearCompleted: {
                                clearCompletedFavoriteTeamProGame(autoGame.game, scope: "business")
                            }
                        )
                    case .nativeAd(let slot):
                        goingNativeAdRow(slot: slot)
                    }
                }
            }
        }
    }

    private func goingNativeAdRow(slot: GoingNativeAdSlot) -> some View {
        GoingNativeAdCard(
            slot: slot,
            shouldRequestAd: FanGeoAdPolicy.shouldMountAdViews()
                && goingProNativeAdsHostVisible
                && goingTabPerf.deferredWorkReady
        )
    }

    private var businessProGamesFilterControl: some View {
        GameOnSegmentedControl(
            tabs: [
                GameOnSegmentedTab(
                    id: BusinessProGameFilter.all,
                    title: "All",
                    badge: businessAllProGamesBadge,
                    tint: FGColor.accentBlue
                ),
                GameOnSegmentedTab(
                    id: BusinessProGameFilter.myTeams,
                    title: "My Teams",
                    badge: businessMyTeamsProGamesBadge,
                    tint: FGColor.accentBlue
                )
            ],
            selection: $selectedBusinessProGameFilter
        )
    }

    private var manualSavedProGamesForDisplay: [SavedProGame] {
        goingTabPerf.cachedManualSavedProGamesForDisplay
    }

    private var favoriteTeamProGamesForDisplay: [FavoriteTeamProGame] {
        goingTabPerf.cachedFavoriteTeamProGamesForDisplay
    }

    private func markGoingScreenAppear(source: String) {
        goingTabPerf.screenAppearAt = CFAbsoluteTimeGetCurrent()
        GoingPerfDebug.screenAppear(source: source)
    }

    private func prepareGoingTabVisibleSurface(reason: String) async {
        if goingTabPerf.screenAppearAt == nil {
            markGoingScreenAppear(source: reason)
        }
        await Task.yield()
        let started = CFAbsoluteTimeGetCurrent()
        if viewModel.savedProGames.isEmpty, let userID = viewModel.currentUserAuthId {
            viewModel.reloadSavedProGamesFromStorage(for: userID)
        }
        rebuildFollowingDisplayCaches(reason: reason, prefetchAvatars: false)
        await rebuildGoingProGamesDisplayCaches(reason: reason)
        let ms = (CFAbsoluteTimeGetCurrent() - started) * 1000
        AppPerfDebug.mainActorBlocked(ms: ms, tab: "following", source: "prepareGoingTabVisibleSurface")
        DebugLogGate.goingTabPerfVerbose(
            "[TabRenderPerf] tab=going visible=true renderMs=\(String(format: "%.2f", ms)) reason=\(reason)"
        )
        recordGoingFirstPaintIfNeeded(source: reason)
        goingTabPerf.deferredWorkReady = true
        goingTabPerf.lastVisibleSurfacePrepareAt = Date()
        goingTabPerf.lastVisibleSurfacePrepareFingerprint = goingTabVisibleSurfaceDataFingerprint()
    }

    private func recordGoingFirstPaintIfNeeded(source: String) {
        guard !goingTabPerf.firstPaintRecorded else { return }
        goingTabPerf.firstPaintRecorded = true
        let elapsedMs = Int(((goingTabPerf.screenAppearAt.map { CFAbsoluteTimeGetCurrent() - $0 } ?? 0) * 1000).rounded())
        let usedCachedData =
            !viewModel.savedProGames.isEmpty
            || !viewModel.favoriteTeamProGames.isEmpty
            || !viewModel.followingTabGoingItems.isEmpty
            || !viewModel.myPickupGameJoinRequestCards.isEmpty
        GoingPerfDebug.firstPaint(
            ms: max(0, elapsedMs),
            usedCachedData: usedCachedData,
            savedGamesCount: viewModel.savedProGames.count,
            favoriteTeamGamesCount: viewModel.favoriteTeamProGames.count,
            source: source
        )
    }

    private func performGoingTabBackgroundRefresh(reason: String) async {
        guard viewModel.isAuthenticatedForSocialFeatures else { return }
        if goingTabPerf.backgroundRefreshInFlight {
            TabPerf.duplicateRefreshCoalesced(name: "goingTabBackgroundRefresh")
            GoingPerfDebug.duplicateRefreshSkipped(source: reason, reason: "inFlight")
            return
        }
        goingTabPerf.backgroundRefreshInFlight = true
        syncGoingProGamesStatusIndicator()
        defer {
            goingTabPerf.backgroundRefreshInFlight = false
            syncGoingProGamesStatusIndicator()
        }

        let startedAt = Date()
        GoingPerfDebug.refreshStarted(source: reason)
        defer {
            let ms = Int(Date().timeIntervalSince(startedAt) * 1000)
            GoingPerfDebug.refreshFinished(source: reason, durationMs: ms)
            Task { await rebuildGoingProGamesDisplayCaches(reason: "refreshFinished:\(reason)") }
        }

        if isBusinessProGamesOnly {
            await reloadBusinessProGamesData(reason: reason)
            return
        }

        guard viewModel.canUseFollowingTab else { return }

        if viewModel.didCompleteTabIntentPreloadRecently("following", within: 12) {
            AppPerfDebug.refreshSkipped(tab: "following", source: reason, reason: "tabPreloadRecent")
            GoingPerfDebug.duplicateRefreshSkipped(source: reason, reason: "tabPreloadRecent")
            await viewModel.fetchSavedProGames(reason: "goingDeferred:\(reason)")
            await scheduleDeferredGoingTabWork(reason: reason)
            return
        }

        if viewModel.isTabIntentPreloadInFlight("following") {
            while viewModel.isTabIntentPreloadInFlight("following") {
                await Task.yield()
                try? await Task.sleep(nanoseconds: 40_000_000)
                if Task.isCancelled { return }
            }
            GoingPerfDebug.duplicateRefreshSkipped(source: reason, reason: "awaitedTabPreload")
            await viewModel.fetchSavedProGames(reason: "goingDeferred:\(reason)")
            await scheduleDeferredGoingTabWork(reason: reason)
            return
        }

        await viewModel.refreshFollowingTabDataGloballyUnlessFresh()
        rebuildFollowingDisplayCaches(reason: "backgroundRefresh:\(reason)", prefetchAvatars: false)
        await viewModel.fetchSavedProGames(reason: "goingBackground:\(reason)")
        await viewModel.loadMyPickupGameJoinRequestsForFollowing(reason: reason)
        await viewModel.loadIncomingPickupGameInvites()
        await scheduleDeferredGoingTabWork(reason: reason)
    }

    private func scheduleDeferredGoingTabWork(reason: String) async {
        GoingPerfDebug.deferredWork("favoriteTeamProGamesRefresh", source: reason)
        await refreshFavoriteTeamProGames(reason: reason)
        rebuildFollowingDisplayCaches(reason: "deferred:\(reason)", prefetchAvatars: false)
        GoingPerfDebug.deferredWork("goingAvatarPrefetch", source: reason)
        prefetchVisibleGoingAvatars(reason: "deferred:\(reason)")
    }

    private func scheduleGoingProGamesDisplayCacheRebuild(reason: String) {
        if goingTabRecentlyRebuiltProGamesDisplay(within: GoingTabPerfState.proGamesDisplayRebuildTTL) {
            return
        }
        if goingTabPerf.proGamesDisplayRebuildTask != nil {
            return
        }
        goingTabPerf.proGamesDisplayRebuildTask = Task { @MainActor in
            await Task.yield()
            try? await Task.sleep(nanoseconds: GoingTabPerfState.deferredBackgroundRefreshDelayNs)
            guard !Task.isCancelled else { return }
            await rebuildGoingProGamesDisplayCaches(reason: reason)
            goingTabPerf.lastProGamesDisplayRebuildAt = Date()
            goingTabPerf.proGamesDisplayRebuildTask = nil
        }
    }

    private func goingTabRecentlyRebuiltProGamesDisplay(within interval: TimeInterval) -> Bool {
        guard let last = goingTabPerf.lastProGamesDisplayRebuildAt else { return false }
        return Date().timeIntervalSince(last) < interval
    }

    private func rebuildGoingProGamesDisplayCaches(reason: String) async {
        goingTabPerf.proGamesDisplayRebuildInFlight = true
        syncGoingProGamesStatusIndicator()
        defer {
            goingTabPerf.proGamesDisplayRebuildInFlight = false
            syncGoingProGamesStatusIndicator()
        }
        let snapshots = viewModel.savedProGames
            .map { viewModel.currentSavedProGameSnapshot($0) }
            .filter { GoingTabCompletedGameVisibility.isProGameVisibleInGoingTab($0) }
        let manualKeys = Set(snapshots.map(\.stableKey))
        let filteredFavorites = viewModel.favoriteTeamProGames
            .map(currentFavoriteTeamProGameSnapshot)
            .filter { !manualKeys.contains($0.game.stableKey) }
            .filter { !isCompletedFavoriteTeamProGameCleared($0.game, scope: "fan") }
            .filter { GoingTabCompletedGameVisibility.isProGameVisibleInGoingTab($0.game) }

        let sortedManual: [SavedProGame]
        let sortedFavorites: [FavoriteTeamProGame]
        if snapshots.count + filteredFavorites.count > 12 {
            sortedManual = await Task.detached(priority: .utility) {
                snapshots.sorted(by: SavedProGame.displaySort)
            }.value
            sortedFavorites = await Task.detached(priority: .utility) {
                filteredFavorites.sorted { SavedProGame.displaySort($0.game, $1.game) }
            }.value
        } else {
            sortedManual = snapshots.sorted(by: SavedProGame.displaySort)
            sortedFavorites = filteredFavorites.sorted { SavedProGame.displaySort($0.game, $1.game) }
        }

        goingTabPerf.cachedManualSavedProGamesForDisplay = sortedManual
        goingTabPerf.cachedFavoriteTeamProGamesForDisplay = sortedFavorites
#if DEBUG
        print("[GoingPerfDebug] rebuildProGamesDisplayCaches reason=\(reason) saved=\(sortedManual.count) favorite=\(sortedFavorites.count)")
#endif
    }

    private var businessFavoriteTeamsForDisplay: [FavoriteTeam] {
        FavoriteTeamsStore.resolvedTeams(fromIDs: Array(viewModel.businessFavoriteTeamIDs).sorted())
    }

    private var businessMyTeamSavedProGamesForDisplay: [SavedProGame] {
        manualSavedProGamesForDisplay.filter { game in
            businessFavoriteTeamsForDisplay.contains { team in
                FavoriteTeamLiveMatcher.matchesLiveMatch(team, homeTeam: game.homeTeam, awayTeam: game.awayTeam)
            }
        }
    }

    private var businessMyTeamProGamesForDisplay: [FavoriteTeamProGame] {
        let manualKeys = Set(manualSavedProGamesForDisplay.map(\.stableKey))
        return viewModel.businessFavoriteTeamProGames
            .map(currentFavoriteTeamProGameSnapshot)
            .filter { !manualKeys.contains($0.game.stableKey) }
            .filter { !isCompletedFavoriteTeamProGameCleared($0.game, scope: "business") }
            .filter { GoingTabCompletedGameVisibility.isProGameVisibleInGoingTab($0.game) }
            .sorted { SavedProGame.displaySort($0.game, $1.game) }
    }

    private var goingPickupHostingGamesForDisplay: [PickupGameRow] {
        viewModel.myPickupGamesForSettings.filter {
            GoingTabCompletedGameVisibility.isPickupGameVisibleInGoingTab(
                row: $0,
                now: followingMyPickupClockTick
            )
        }
    }

    private func currentFavoriteTeamProGameSnapshot(_ item: FavoriteTeamProGame) -> FavoriteTeamProGame {
        FavoriteTeamProGame(
            game: viewModel.currentSavedProGameSnapshot(item.game),
            favoriteTeamID: item.favoriteTeamID,
            favoriteTeamName: item.favoriteTeamName
        )
    }

    private var businessAllProGamesBadge: String? {
        let count = manualSavedProGamesForDisplay.count + businessMyTeamProGamesForDisplay.count
        guard count > 0 else { return nil }
        return count > 9 ? "9+" : "\(count)"
    }

    private var businessMyTeamsProGamesBadge: String? {
        let count = businessMyTeamSavedProGamesForDisplay.count + businessMyTeamProGamesForDisplay.count
        guard count > 0 else { return nil }
        return count > 9 ? "9+" : "\(count)"
    }

    private func favoriteTeamAutoFollowMatch(for game: SavedProGame) -> FavoriteTeamProGame? {
        viewModel.favoriteTeamProGames.first { $0.game.stableKey == game.stableKey }
    }

    private func businessFavoriteTeamMatch(for game: SavedProGame) -> FavoriteTeamProGame? {
        viewModel.businessFavoriteTeamProGames.first { $0.game.stableKey == game.stableKey }
    }

    private func savedProGameBadges(for game: SavedProGame) -> [String] {
        var badges: [String] = []
        if favoriteTeamAutoFollowMatch(for: game) != nil {
            badges.append("Favorite Team")
        }
        return badges
    }

    private func favoriteTeamProGameBadges() -> [String] {
        ["Favorite Team"]
    }

    private func businessSavedProGameBadges(for game: SavedProGame) -> [String] {
        var badges: [String] = []
        if businessFavoriteTeamMatch(for: game) != nil || businessMyTeamSavedProGamesForDisplay.contains(where: { $0.stableKey == game.stableKey }) {
            badges.append("My Teams")
        }
        return badges
    }

    private func businessMyTeamProGameBadges() -> [String] {
        ["My Teams"]
    }

    private var goingSavedProGamesShowsCompletedVisibilityNote: Bool {
        manualSavedProGamesForDisplay.contains(where: \.isFinal)
    }

    @ViewBuilder
    private var goingSavedProGamesCompletedVisibilityNote: some View {
        if goingSavedProGamesShowsCompletedVisibilityNote {
            Text("ⓘ Completed games remain visible for 48 hours after they finish.")
                .font(FGTypography.caption)
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 2)
                .padding(.top, 2)
                .padding(.bottom, 4)
                .accessibilityAddTraits(.isStaticText)
        }
    }

    private func sectionEyebrow(_ text: String) -> some View {
        Text(text.uppercased())
            .font(.caption2.weight(.bold))
            .tracking(0.8)
            .foregroundStyle(FGColor.mutedText(followingColorScheme))
            .padding(.horizontal, 2)
    }

    private var favoriteTeamAlertsToggleRow: some View {
        Toggle(isOn: favoriteTeamAlertsBinding) {
            VStack(alignment: .leading, spacing: 3) {
                Text("Team Alerts")
                    .font(FGTypography.caption.weight(.bold))
                    .foregroundStyle(FGColor.primaryText(followingColorScheme))

                Text("Get kickoff, score, and final alerts for games involving your favorite teams.")
                    .font(FGTypography.metadata)
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .toggleStyle(.switch)
        .tint(FGColor.accentGreen)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill((favoriteTeamProGameAlertsEnabled ? FGColor.accentGreen : FGColor.mutedText(followingColorScheme)).opacity(followingColorScheme == .dark ? 0.14 : 0.08))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder((favoriteTeamProGameAlertsEnabled ? FGColor.accentGreen : FGColor.mutedText(followingColorScheme)).opacity(followingColorScheme == .dark ? 0.28 : 0.16), lineWidth: 1)
        )
    }

    private var favoriteTeamAlertsBinding: Binding<Bool> {
        Binding(
            get: { favoriteTeamProGameAlertsEnabled },
            set: { enabled in
                Task {
                    await viewModel.setFavoriteTeamProGameAlertsEnabled(
                        enabled,
                        games: viewModel.favoriteTeamProGames,
                        reason: "goingProTeamAlertsToggle"
                    )
                    favoriteTeamProGameAlertsEnabled = viewModel.notificationSettingsStore.favoriteTeamProGameAlertsEnabled
                }
            }
        )
    }

    private func refreshFavoriteTeamProGamesIfVisible(reason: String) {
        guard isFollowingTabSelected, activeGoingMode == .proGames else { return }
        if isBusinessProGamesOnly {
            Task {
                await Task.yield()
                await refreshBusinessFavoriteTeamProGames(reason: reason)
            }
        } else {
            Task {
                await Task.yield()
                await refreshFavoriteTeamProGames(reason: reason)
            }
        }
    }

    private func refreshFavoriteTeamProGames(reason: String, forceRefresh: Bool = false) async {
        guard viewModel.isAuthenticatedForSocialFeatures,
              (viewModel.canUseFollowingTab || isBusinessProGamesOnly) else {
            await MainActor.run {
                viewModel.favoriteTeamProGames = []
            }
            return
        }
#if DEBUG
        print("[SavedProGames] favoriteTeamAutoFollowRefresh reason=\(reason)")
#endif
        let window = ProGamesFavoriteTeamAutoFollowPreference.Window.resolved(rawValue: proGamesFavoriteTeamWindowDays)
        await viewModel.refreshFavoriteTeamProGames(
            enabled: proGamesAutoFollowFavoriteTeams,
            windowDays: window.rawValue,
            favoriteTeamIDsRaw: favoriteTeamIDsRaw,
            forceRefresh: forceRefresh
        )
    }

    private func refreshBusinessFavoriteTeamProGames(reason: String, forceRefresh: Bool = false) async {
        guard viewModel.isAuthenticatedForSocialFeatures, isBusinessProGamesOnly else {
            await MainActor.run {
                viewModel.businessFavoriteTeamProGames = []
            }
            return
        }
#if DEBUG
        print("[BusinessFavoriteTeams] proGameRefresh reason=\(reason)")
#endif
        await viewModel.refreshBusinessFavoriteTeamProGames(windowDays: 30, forceRefresh: forceRefresh)
    }

    private var playingGamesContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if !viewModel.canFanUsePickupGamesUI {
                emptyCard(
                    icon: "figure.run",
                    title: "Games unavailable",
                    subtitle: "Switch to a fan account to join and play games."
                )
            } else if shouldShowPlayingPickupLoadingState {
                pickupSubtabLoadingCard(message: "Loading games…")
            } else if playingGameCards.isEmpty {
                goingRichEmptyCard(
                    title: "⚽ No pickup games joined yet",
                    description: "Join local pickup games and track them here.",
                    buttonTitle: "Find Pickup Games",
                    buttonAction: openDiscoverForPickupGamesFromGoing
                )
            } else {
                joinedGamesListContent
            }
        }
        .padding(.top, 6)
        .onAppear {
            guard viewModel.canFanUsePickupGamesUI else { return }
            viewModel.acknowledgePickupFollowingGamesToPlayActivity()
        }
    }

    private var hostingGamesContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if !viewModel.canFanUsePickupGamesUI {
                emptyCard(
                    icon: "figure.run",
                    title: "Games unavailable",
                    subtitle: "Switch to a fan account to create and manage games."
                )
            } else {
                hostPickupInlineCTA

                if shouldShowHostingPickupLoadingState {
                    pickupSubtabLoadingCard(message: "Loading games…")
                } else if viewModel.myPickupGamesForSettings.isEmpty, viewModel.myRemovedPickupGamesForSettings.isEmpty {
                    goingRichEmptyCard(
                        title: "🏆 You're not hosting any games yet",
                        description: "Create a pickup game and invite local players."
                    )
                } else {
                    hostedGamesListContent
                }
            }
        }
        .padding(.top, 6)
        .onAppear {
            guard viewModel.canFanUsePickupGamesUI else { return }
            followingMyPickupClockTick = Date()
            let hasCachedHostingData =
                !viewModel.myPickupGamesForSettings.isEmpty
                || !viewModel.myRemovedPickupGamesForSettings.isEmpty
            let awaitingInitialHostLoad =
                viewModel.lastMyPickupGamesLightweightLoadAt == nil
                && !hasCachedHostingData
            if awaitingInitialHostLoad {
                followingHostingPickupLoadInFlight = true
            }
            if hasCachedHostingData {
                Task { @MainActor in
                    await Task.yield()
                    try? await Task.sleep(nanoseconds: 200_000_000)
                    defer { followingHostingPickupLoadInFlight = false }
                    await loadHostingPickupGamesAfterAppear()
                }
            } else {
                Task {
                    defer { followingHostingPickupLoadInFlight = false }
                    await loadHostingPickupGamesAfterAppear()
                }
            }
            scheduleFollowingMyPickupExpiryRefreshIfNeeded(now: Date())
        }
    }

    @MainActor
    private func loadHostingPickupGamesAfterAppear() async {
        await viewModel.loadMyPickupGamesForSettings()
        if let uid = viewModel.currentUserAuthId {
            await viewModel.refreshPickupCreatorPublicRatingStats(creatorUserIds: [uid])
        }
        logFollowingMyPickupGames(action: "gamesListAppear")
    }

    private var invitesGamesContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if !viewModel.canFanUsePickupGamesUI {
                emptyCard(
                    icon: "envelope",
                    title: "Invites unavailable",
                    subtitle: "Switch to a fan account to receive pickup game invites."
                )
            } else if viewModel.incomingPickupGameInvites.isEmpty {
                goingRichEmptyCard(
                    title: "📨 No pickup invitations",
                    description: "Invitations from friends and organizers will appear here."
                )
            } else {
                incomingPickupGameInvitesContent
            }
        }
        .padding(.top, 6)
        .onAppear {
            guard viewModel.canFanUsePickupGamesUI else { return }
            Task { await viewModel.loadIncomingPickupGameInvites() }
        }
        .animation(.spring(response: 0.32, dampingFraction: 0.86), value: viewModel.incomingPickupGameInvites.count)
    }

    private var pickupPlayingTabBadge: String? {
        let count = viewModel.pickupActivityCount
        guard count > 0 else { return nil }
        return count > 9 ? "9+" : "\(count)"
    }

    private var venueGamesTabBadge: String? {
        compactTabBadgeCount(goingVenueGameItems.count + viewModel.followingTabSavedVenues.count)
    }

    private var pickupGamesTabBadge: String? {
        compactTabBadgeCount(
            playingGameCards.count
                + viewModel.myPickupGamesForSettings.count
                + viewModel.incomingPickupGameInvites.count
        )
    }

    private var savedProGamesTabBadge: String? {
        let count = isBusinessProGamesOnly
            ? manualSavedProGamesForDisplay.count + businessMyTeamProGamesForDisplay.count
            : manualSavedProGamesForDisplay.count + favoriteTeamProGamesForDisplay.count
        return compactTabBadgeCount(count)
    }

    private func compactTabBadgeCount(_ count: Int) -> String? {
        guard count > 0 else { return nil }
        return count > 9 ? "9+" : "\(count)"
    }

    private var playingGameCards: [PickupGameJoinRequestCardDisplay] {
        cachedPlayingGameCards
    }

    private var pickupHostingTabBadge: String? {
        let count = viewModel.pendingPickupGameJoinRequestCount
        guard count > 0 else { return nil }
        return count > 9 ? "9+ Pending" : "\(count) Pending"
    }

    private var pickupInvitesTabBadge: String? {
        let count = viewModel.incomingPickupGameInvites.count
        guard count > 0 else { return nil }
        return count > 9 ? "9+" : "\(count)"
    }

    private func goingTabbedPanel<Tabs: View, Content: View>(
        title: String,
        subtitle: String,
        @ViewBuilder tabs: () -> Tabs,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .tracking(1.0)
                    .foregroundStyle(FGColor.mutedText(followingColorScheme))
                Text(subtitle)
                    .font(FGTypography.caption)
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .fixedSize(horizontal: false, vertical: true)
            }

            tabs()

            Divider()
                .overlay(FGColor.divider(followingColorScheme).opacity(0.65))
                .padding(.top, 2)

            content()
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color(.secondarySystemGroupedBackground).opacity(followingColorScheme == .dark ? 0.38 : 0.72))
        }
        .overlay {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .strokeBorder(FGColor.divider(followingColorScheme).opacity(0.72), lineWidth: 1)
        }
        .shadow(color: Color.black.opacity(followingColorScheme == .dark ? 0.20 : 0.055), radius: 10, y: 3)
    }

    private func goingCategoryBlock<Content: View>(
        title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(title)
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(FGColor.mutedText(followingColorScheme))

            content()
        }
    }

    private var goingHubParticipationSummaryCard: some View {
        HStack(spacing: 12) {
            goingHubMetricPill(
                value: viewModel.myPickupGamesForSettings.count + viewModel.myPickupGameJoinRequestCards.count,
                label: "Pickup",
                tint: FGColor.accentGreen
            )
            goingHubMetricPill(
                value: viewModel.followingTabGoingItems.count,
                label: "I’m Going",
                tint: Color.orange
            )
            goingHubMetricPill(
                value: chatViewModel.friends.count,
                label: "Social",
                tint: FGColor.accentBlue
            )
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
    }

    private func goingHubMetricPill(value: Int, label: String, tint: Color) -> some View {
        VStack(spacing: 4) {
            Text(value > 0 ? "\(value)" : "0")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(FGColor.primaryText(followingColorScheme))
            Text(label)
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(tint.opacity(followingColorScheme == .dark ? 0.13 : 0.09), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private var goingHubUpcomingSubtitle: String {
        let attendance = viewModel.followingTabGoingItems.count
        let joined = viewModel.myPickupGameJoinRequestCards.count
        let hosting = viewModel.myPickupGamesForSettings.count
        let total = attendance + joined + hosting
        guard total > 0 else { return "Your next games and plans will collect here." }
        if total == 1 { return "1 upcoming thing you’re part of." }
        return "\(total) upcoming things you’re part of."
    }

    private var goingHubPickupActivityCount: Int {
        viewModel.pendingPickupGameJoinRequestCount + viewModel.pickupActivityCount
    }

    private var goingHubActivityBadgeState: String {
        if viewModel.pendingPickupGameJoinRequestCount > 0 {
            return "pendingResponse:\(viewModel.pendingPickupGameJoinRequestCount)"
        }
        if viewModel.pickupActivityCount > 0 || viewModel.hasUnreadPickupActivity {
            return "pickupActivity:\(max(viewModel.pickupActivityCount, 1))"
        }
        return "none"
    }

    private var goingHubShouldShowActivityStrip: Bool {
        goingHubActivityBadgeState != "none"
    }

    private var goingHubActivityStrip: some View {
        HStack(spacing: 9) {
            Circle()
                .fill(Color.orange.opacity(0.92))
                .frame(width: 7, height: 7)

            Text(goingHubActivityText)
                .font(FGTypography.caption.weight(.semibold))
                .foregroundStyle(FGColor.primaryText(followingColorScheme))
                .lineLimit(2)

            Spacer(minLength: 0)

            Text("Pickup")
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(Color.orange.opacity(0.95))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color.orange.opacity(followingColorScheme == .dark ? 0.16 : 0.11), in: Capsule())
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 16))
        .accessibilityLabel(goingHubActivityText)
    }

    private var goingHubActivityText: String {
        if viewModel.pendingPickupGameJoinRequestCount == 1 {
            return "1 player waiting to join."
        }
        if viewModel.pendingPickupGameJoinRequestCount > 1 {
            return "\(viewModel.pendingPickupGameJoinRequestCount) players waiting to join."
        }
        if viewModel.pickupActivityCount == 1 {
            return "New activity on a pickup game you joined."
        }
        if viewModel.pickupActivityCount > 1 {
            return "\(viewModel.pickupActivityCount) pickup games have new activity."
        }
        return "Pickup activity is waiting in Going."
    }

    private func goingHubSection<Content: View>(
        eyebrow: String,
        title: String,
        subtitle: String,
        icon: String,
        activityCount: Int?,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(FGColor.accentGreen)
                    .frame(width: 28, height: 28)
                    .background(FGColor.accentGreen.opacity(followingColorScheme == .dark ? 0.16 : 0.11), in: Circle())

                VStack(alignment: .leading, spacing: 3) {
                    Text(eyebrow.uppercased())
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(0.7)
                        .foregroundStyle(FGColor.mutedText(followingColorScheme))
                    Text(title)
                        .font(FGTypography.sectionTitle)
                        .foregroundStyle(FGColor.primaryText(followingColorScheme))
                    Text(subtitle)
                        .font(FGTypography.caption)
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                        .fixedSize(horizontal: false, vertical: true)
                }

                Spacer(minLength: 0)

                if let activityCount, activityCount > 0 {
                    goingHubSmallBadge(count: activityCount)
                }
            }

            content()
        }
    }

    private func goingHubSmallBadge(count: Int) -> some View {
        let label = count > 9 ? "9+" : "\(count)"
        return Text(label)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .frame(minWidth: 20, minHeight: 20)
            .padding(.horizontal, count > 9 ? 4 : 0)
            .background(Color.orange.opacity(0.92), in: Capsule())
            .overlay(Capsule().strokeBorder(Color.white.opacity(0.5), lineWidth: 1))
            .accessibilityLabel("\(count) pickup activity items")
    }

    private var hostPickupInlineCTA: some View {
        Button {
            openCreatePickupFromGoing()
        } label: {
            HStack(alignment: .center, spacing: 12) {
                Image(systemName: "plus")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 30, height: 30)
                    .background(FGColor.accentGreen, in: Circle())

                VStack(alignment: .leading, spacing: 2) {
                    Text("Create Game")
                        .font(FGTypography.cardTitle)
                        .foregroundStyle(FGColor.primaryText(followingColorScheme))
                    Text("Create a casual game and manage it here.")
                        .font(FGTypography.caption)
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                }

                Spacer(minLength: 0)

                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(FGColor.mutedText(followingColorScheme))
            }
            .padding(14)
            .background {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(.ultraThinMaterial)
            }
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 20))
        }
        .buttonStyle(.plain)
        .disabled(!viewModel.canFanUsePickupGamesUI)
        .opacity(viewModel.canFanUsePickupGamesUI ? 1 : 0.55)
        .accessibilityLabel("Create Game")
    }

    private var venueGamesTabContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if goingVenueGameItems.isEmpty {
                goingRichEmptyCard(
                    title: "🏟️ No venue games yet",
                    description: "Discover sports bars, watch parties, and venue events near you.",
                    buttonTitle: "Explore Discover",
                    buttonAction: openDiscoverFromGoing
                )
            } else {
                VStack(spacing: 12) {
                    ForEach(goingVenueGameItems) { item in
                        goingPlanCard(item, isCompleted: watchingVenueGameIsCompleted(item))
                    }
                }
            }
        }
        .padding(.top, 6)
    }

    private var savedVenuesTabContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if viewModel.followingTabSavedVenues.isEmpty {
                goingRichEmptyCard(
                    title: "❤️ No saved venues yet",
                    description: "Save sports bars and watch spots to quickly find them later.",
                    buttonTitle: "Find Watch Spots",
                    buttonAction: openDiscoverFromGoing
                )
            } else {
                VStack(spacing: 12) {
                    ForEach(viewModel.followingTabSavedVenues) { bar in
                        venueCard(bar)
                    }
                }
                .animation(.spring(response: 0.36, dampingFraction: 0.86), value: viewModel.favoriteVenueIDs)
            }
        }
        .padding(.top, 6)
    }

    private func openProGamePredictionSheet(for game: SavedProGame) {
#if DEBUG
        print("[ProPredictionPerf] tapReceived gameId=\(game.stableKey)")
#endif
        proGamePredictionSheet = ProGamePredictionSheetContext(game: game)
#if DEBUG
        print("[ProPredictionPerf] sheetPresented gameId=\(game.stableKey)")
#endif
    }

    private func savedProGameCard(
        _ game: SavedProGame,
        badges: [String],
        showsUnsaveButton: Bool = true,
        showsScoreUpdatesControl: Bool = true,
        favoriteTeamAlertItem: FavoriteTeamProGame? = nil,
        onClearCompleted: (() -> Void)? = nil
    ) -> some View {
        let displayGame = viewModel.currentSavedProGameSnapshot(game)
        let sportType = displayGame.liveSportVisualType
        let accent = sportType.catalogAccent
        let completedAccent = FGColor.mutedText(followingColorScheme)
        let liveAccent = FGColor.dangerRed
        let isLiveCard = displayGame.matchStatus.isHappeningNow && !displayGame.isFinal
        let cardAccent = displayGame.isFinal ? completedAccent : (isLiveCard ? liveAccent : accent)
        let borderOpacity = savedProGameCardBorderOpacity(displayGame)
        let featuredEvent = savedProGameFeaturedEvent(displayGame)

        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 14) {
                ProGameSportBadgeView(
                    sportType: sportType,
                    diameter: 56,
                    featuredEvent: featuredEvent,
                    featuredEventSlug: displayGame.featuredEventSlug
                )

                VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .firstTextBaseline, spacing: 7) {
                    ProGameLeagueChip(
                        sportType: sportType,
                        featuredEvent: featuredEvent,
                        league: displayGame.league
                    )

                    Text(savedProGameStatusText(displayGame))
                        .font(displayGame.isFinal ? .caption.weight(.heavy) : .caption2.weight(.bold))
                        .foregroundStyle(statusTint(for: displayGame, fallback: cardAccent))
                        .padding(.horizontal, displayGame.isFinal ? 10 : 8)
                        .padding(.vertical, displayGame.isFinal ? 5 : 3)
                        .background(
                            Capsule(style: .continuous)
                                .fill(statusTint(for: displayGame, fallback: cardAccent).opacity(displayGame.isFinal ? (followingColorScheme == .dark ? 0.20 : 0.12) : (followingColorScheme == .dark ? 0.18 : 0.10)))
                        )
                }

                if !badges.isEmpty {
                    savedProGameStatusBadges(badges, accent: cardAccent, isFinal: displayGame.isFinal)
                }

                Text(savedProGameTitle(displayGame))
                    .font(FGTypography.cardTitle)
                    .foregroundStyle(FGColor.primaryText(followingColorScheme))
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)

                Text(savedProGameDateLine(displayGame))
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .lineLimit(1)

                Text("\(AppSportCatalog.displayLabel(forSportToken: displayGame.sport)) · \(displayGame.league)")
                    .font(FGTypography.caption)
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .lineLimit(1)
                    .truncationMode(.tail)

                if showsScoreUpdatesControl, !displayGame.isFinal {
                    if let favoriteTeamAlertItem {
                        favoriteTeamProGameAlertsControl(favoriteTeamAlertItem, accent: cardAccent)
                    } else {
                        savedProGameScoreUpdatesControl(displayGame, accent: cardAccent)
                    }
                }

                if let tv = displayGame.tvSummary, !tv.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Label(tv, systemImage: "tv.fill")
                        .font(FGTypography.metadata.weight(.semibold))
                        .foregroundStyle(cardAccent)
                        .lineLimit(1)
                }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Spacer(minLength: 0)

                if showsUnsaveButton {
                    savedProGameClearControl(displayGame)
                } else if displayGame.isFinal, let onClearCompleted {
                    completedFavoriteTeamProGameClearControl(onClearCompleted)
                }
            }

            if savedProGameShouldShowScore(displayGame) {
                if displayGame.isFinal {
                    savedProGameScoreboardSection(displayGame, isFinal: true, accent: cardAccent)
                } else {
                    savedProGameScoreboardSection(displayGame, isFinal: false, accent: cardAccent)
                }
            }

            if displayGame.supportsProGamePredictions {
                ProGamePredictionFooterRow(
                    game: displayGame,
                    summary: viewModel.proGamePredictionSummaries[displayGame.stableKey]
                ) {
                    openProGamePredictionSheet(for: displayGame)
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(savedProGameCardBackgroundFill(displayGame, accent: cardAccent))
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(cardAccent.opacity(borderOpacity), lineWidth: 1)
        )
        .opacity(1)
        .id(savedProGameCardRefreshToken(displayGame))
        .onAppear {
            logSavedProGameStatusDebug(displayGame)
            logSavedProGameScoringEventDebug(displayGame)
        }
    }

    private func savedProGameCardBackgroundFill(_ game: SavedProGame, accent: Color) -> Color {
        if game.isFinal {
            return Color.gray.opacity(followingColorScheme == .dark ? 0.24 : 0.22)
        }
        if game.matchStatus.isHappeningNow {
            return FGColor.dangerRed.opacity(followingColorScheme == .dark ? 0.16 : 0.09)
        }
        return Color.clear
    }

    private func savedProGameCardBorderOpacity(_ game: SavedProGame) -> Double {
        if game.isFinal {
            return followingColorScheme == .dark ? 0.44 : 0.34
        }
        if game.matchStatus.isHappeningNow {
            return followingColorScheme == .dark ? 0.48 : 0.30
        }
        return followingColorScheme == .dark ? 0.38 : 0.22
    }

    private func savedProGameClearControl(_ game: SavedProGame) -> some View {
        VStack(spacing: 7) {
            if game.isFinal {
                Button("Clear") {
                    clearSavedProGame(game)
                }
                .font(.caption2.weight(.bold))
                .foregroundStyle(FGColor.mutedText(followingColorScheme))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(
                    Capsule(style: .continuous)
                        .fill(FGColor.mutedText(followingColorScheme).opacity(followingColorScheme == .dark ? 0.14 : 0.08))
                )
                .buttonStyle(.plain)
                .accessibilityLabel("Clear completed pro game")
            } else {
                Button {
                    clearSavedProGame(game)
                } label: {
                    Image(systemName: "heart.fill")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(Color.red.opacity(0.95))
                        .frame(width: 32, height: 32)
                        .background(Color.red.opacity(followingColorScheme == .dark ? 0.18 : 0.10), in: Circle())
                        .overlay(Circle().strokeBorder(Color.red.opacity(followingColorScheme == .dark ? 0.38 : 0.24), lineWidth: 1))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Unsave pro game")
            }
        }
    }

    private func completedFavoriteTeamProGameClearControl(_ action: @escaping () -> Void) -> some View {
        Button("Clear") {
            action()
        }
        .font(.caption2.weight(.bold))
        .foregroundStyle(FGColor.mutedText(followingColorScheme))
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(
            Capsule(style: .continuous)
                .fill(FGColor.mutedText(followingColorScheme).opacity(followingColorScheme == .dark ? 0.14 : 0.08))
        )
        .buttonStyle(.plain)
        .accessibilityLabel("Clear completed favorite team pro game")
    }

    private func savedProGameScoreUpdatesControl(
        _ game: SavedProGame,
        accent _: Color
    ) -> some View {
        let isEnabled = viewModel.savedProGameScoreUpdatesEnabled(for: game)
        let controlAccent = isEnabled ? FGColor.accentGreen : FGColor.mutedText(followingColorScheme)

        return Button {
            viewModel.setSavedProGameScoreUpdatesEnabled(!isEnabled, for: game)
        } label: {
            HStack(spacing: 6) {
                Image(systemName: isEnabled ? "bell.fill" : "bell.slash")
                    .font(.system(size: 11, weight: .bold))
                Text("Live Alerts \(isEnabled ? "ON" : "OFF")")
                    .font(.caption2.weight(.bold))
            }
            .foregroundStyle(controlAccent)
            .padding(.horizontal, 9)
            .padding(.vertical, 5)
            .background(
                Capsule(style: .continuous)
                    .fill(controlAccent.opacity(followingColorScheme == .dark ? 0.16 : 0.09))
            )
            .overlay(
                Capsule(style: .continuous)
                    .strokeBorder(controlAccent.opacity(followingColorScheme == .dark ? 0.28 : 0.18), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Live alerts for this game \(isEnabled ? "on" : "off")")
        .accessibilityHint("Goals, halftime, cards and other live updates.")
    }

    private func favoriteTeamProGameAlertsControl(_ item: FavoriteTeamProGame, accent _: Color) -> some View {
        let isEnabled = viewModel.favoriteTeamProGameScoreUpdatesEnabled(for: item.game)
        let controlAccent = isEnabled ? FGColor.accentGreen : FGColor.mutedText(followingColorScheme)

        return Button {
            Task {
                await viewModel.setFavoriteTeamProGameScoreUpdatesEnabled(
                    !isEnabled,
                    for: item,
                    reason: "goingProFavoriteTeamAlertToggle"
                )
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: isEnabled ? "bell.fill" : "bell.slash")
                    .font(.system(size: 11, weight: .bold))
                Text("Live Alerts \(isEnabled ? "ON" : "OFF")")
                    .font(.caption2.weight(.bold))
            }
            .foregroundStyle(controlAccent)
            .padding(.horizontal, 9)
            .padding(.vertical, 5)
            .background(
                Capsule(style: .continuous)
                    .fill(controlAccent.opacity(followingColorScheme == .dark ? 0.16 : 0.09))
            )
            .overlay(
                Capsule(style: .continuous)
                    .strokeBorder(controlAccent.opacity(followingColorScheme == .dark ? 0.28 : 0.18), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Live alerts for this game \(isEnabled ? "on" : "off")")
        .accessibilityHint("Goals, halftime, cards and other live updates.")
    }

    private func clearSavedProGame(_ game: SavedProGame) {
        withAnimation(.spring(response: 0.28, dampingFraction: 0.86)) {
            viewModel.removeSavedProGame(id: game.stableKey)
            viewModel.showSocialActionToast("Removed from Pro Games.", isError: false)
        }
    }

    private func clearCompletedFavoriteTeamProGame(_ game: SavedProGame, scope: String) {
        guard game.isFinal else { return }
        withAnimation(.spring(response: 0.28, dampingFraction: 0.86)) {
            var tokens = clearedCompletedFavoriteTeamProGameTokens()
            tokens.insert(completedFavoriteTeamProGameClearToken(for: game, scope: scope))
            clearedCompletedFavoriteTeamProGamesRaw = tokens.sorted().joined(separator: "\n")
            viewModel.showSocialActionToast("Cleared completed Pro Game.", isError: false)
            Task {
                await viewModel.removeSavedProGameFromAppleCalendar(
                    identifier: game.stableKey,
                    action: "remove",
                    forceBypassFreshness: true
                )
            }
        }
    }

    private func isCompletedFavoriteTeamProGameCleared(_ game: SavedProGame, scope: String) -> Bool {
        guard game.isFinal else { return false }
        return clearedCompletedFavoriteTeamProGameTokens().contains(
            completedFavoriteTeamProGameClearToken(for: game, scope: scope)
        )
    }

    private func clearedCompletedFavoriteTeamProGameTokens() -> Set<String> {
        Set(
            clearedCompletedFavoriteTeamProGamesRaw
                .split(whereSeparator: \.isNewline)
                .map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
        )
    }

    private func completedFavoriteTeamProGameClearToken(for game: SavedProGame, scope: String) -> String {
        let userScope = viewModel.currentUserAuthId?.uuidString.lowercased() ?? "guest"
        return "\(userScope)|\(scope)|\(game.stableKey)"
    }

    private func savedProGameStatusBadges(_ badges: [String], accent: Color, isFinal: Bool = false) -> some View {
        HStack(spacing: 6) {
            ForEach(badges, id: \.self) { badge in
                let badgeAccent = isFinal
                    ? FGColor.mutedText(followingColorScheme)
                    : accent
                Label(badge, systemImage: "star.fill")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(badgeAccent)
                    .lineLimit(1)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(
                        Capsule(style: .continuous)
                            .fill(badgeAccent.opacity(followingColorScheme == .dark ? 0.18 : 0.10))
                    )
            }
        }
    }

    private func savedProGameFeaturedEvent(_ game: SavedProGame) -> FeaturedEvent? {
        guard let slug = game.featuredEventSlug?.trimmingCharacters(in: .whitespacesAndNewlines), !slug.isEmpty else {
            return nil
        }
        let normalizedSlug = LiveMatchFilters.normalizedSearchText(slug)
        return viewModel.activeFeaturedEvents.first {
            LiveMatchFilters.normalizedSearchText($0.slug) == normalizedSlug
        } ?? FeaturedEvent.fallbackEvents.first {
            LiveMatchFilters.normalizedSearchText($0.slug) == normalizedSlug
        }
    }

    private func savedProGameTitle(_ game: SavedProGame) -> String {
        "\(savedProGameTeamName(game.awayTeam)) at \(savedProGameTeamName(game.homeTeam))"
    }

    private func savedProGameTeamName(_ teamName: String) -> String {
        let trimmed = teamName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              CountryFlagHelper.isCountry(trimmed),
              let flag = CountryFlagHelper.flag(for: trimmed, source: "GoingPro"),
              !flag.isEmpty else {
            return trimmed
        }
        return "\(flag) \(trimmed)"
    }

    private func savedProGameDateLine(_ game: SavedProGame) -> String {
        let date = game.startTime.formatted(.dateTime.month(.abbreviated).day().year())
        let time = CompactGameTimeFormatter.timeWithZone(
            for: game.startTime,
            timeZoneOption: viewModel.selectedTimeZone
        )
        return "\(date) · \(time)"
    }

    private func savedProGameStatusText(_ game: SavedProGame) -> String {
        switch game.matchStatus {
        case .live:
            return savedProGameLiveStatusText(game)
        case .halfTime:
            return "HT"
        case .fullTime:
            return "FINAL"
        case .scheduled:
            return "Scheduled"
        }
    }

    private func savedProGameLiveStatusText(_ game: SavedProGame) -> String {
        if savedProGameIsSoccer(game),
           let minute = game.minute,
           minute > 0 {
            return "LIVE \(minute)'"
        }

        if !savedProGameIsSoccer(game),
           let clock = savedProGameNonSoccerClockText(game) {
            return clock
        }

        return "LIVE"
    }

    private func savedProGameIsSoccer(_ game: SavedProGame) -> Bool {
        let text = LiveMatchFilters.normalizedSearchText("\(game.sport) \(game.league) \(game.featuredEventSlug ?? "")")
        guard !text.contains("american football"),
              !text.contains("nfl") else {
            return false
        }
        return text.contains("soccer")
            || text.contains("football")
            || text.contains("fifa")
            || text.contains("world cup")
            || text.contains("uefa")
            || text.contains("friendly")
            || text.contains("nations league")
    }

    private func savedProGameNonSoccerClockText(_ game: SavedProGame) -> String? {
        let trimmed = game.liveClockText?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !trimmed.isEmpty else { return nil }

        let normalized = LiveMatchFilters.normalizedSearchText(trimmed)
        guard !["live", "ht", "ft", "final", "scheduled", "not started"].contains(normalized) else {
            return nil
        }
        if trimmed.contains(":") {
            return trimmed
        }
        if normalized.hasPrefix("q") || normalized.hasPrefix("p") || normalized.contains("period") {
            return trimmed
        }
        if normalized.hasPrefix("1st") || normalized.hasPrefix("2nd") || normalized.hasPrefix("3rd") || normalized.hasPrefix("4th") {
            return trimmed
        }
        return nil
    }

    private func logSavedProGameStatusDebug(_ game: SavedProGame) {
#if DEBUG
        guard SavedProGameStatusDiagnostics.enabled else { return }
        let resolved = viewModel.savedProGameDisplayStatusDebugSource(for: game)
        let resolvedGame = resolved.game
        print(
            "[SavedProGameStatusDebug] " +
            "gameId=\(resolvedGame.stableKey) " +
            "teams=\"\(resolvedGame.awayTeam) at \(resolvedGame.homeTeam)\" " +
            "rawStatus=\(resolvedGame.rawMatchStatus ?? "nil") " +
            "normalizedStatus=\(resolvedGame.matchStatus.rawValue) " +
            "score=\(resolvedGame.scoreAway)-\(resolvedGame.scoreHome) " +
            "sourceUsed=\"\(resolved.source)\""
        )
#endif
    }

    private func logSavedProGameScoringEventDebug(_ game: SavedProGame) {
        let displayGame = viewModel.currentSavedProGameSnapshot(game)
        LiveScoringEventDebug.log(
            gameId: displayGame.stableKey,
            eventId: displayGame.externalId,
            sport: displayGame.sport,
            sportType: displayGame.liveSportVisualType,
            matchStatus: displayGame.matchStatus,
            rawMatchStatus: displayGame.rawMatchStatus,
            homeTeam: displayGame.homeTeam,
            awayTeam: displayGame.awayTeam,
            timelineEvents: displayGame.timelineEvents ?? [],
            timelineFetched: !(displayGame.timelineEvents ?? []).isEmpty
        )
#if DEBUG
        ScoringTimelineDebug.log(
            gameId: displayGame.stableKey,
            scoreHome: displayGame.scoreHome,
            scoreAway: displayGame.scoreAway,
            homeTeam: displayGame.homeTeam,
            awayTeam: displayGame.awayTeam,
            sportType: displayGame.liveSportVisualType,
            timelineEvents: displayGame.timelineEvents ?? []
        )
#endif
    }

    private func savedProGameShouldShowScore(_ game: SavedProGame) -> Bool {
        if game.matchStatus.isHappeningNow || game.isFinal { return true }
        guard game.matchStatus == .scheduled else { return false }
        let snapshot = viewModel.currentSavedProGameSnapshot(game)
        if let match = viewModel.liveMatches.first(where: { SavedProGame.stableKey(for: $0) == game.stableKey }) {
            return match.scoresAreAvailable
        }
        return snapshot.scoreHome > 0 || snapshot.scoreAway > 0
    }

    private func savedProGameScoreboardSection(
        _ displayGame: SavedProGame,
        isFinal: Bool,
        accent: Color
    ) -> some View {
        let mergedTimelineEvents = goingProMergedTimelineEvents(for: displayGame)
        let timelineSummary = LiveScoringTimelineBuilder.resolvedGoalDisplaySummary(
            sportType: displayGame.liveSportVisualType,
            timelineEvents: mergedTimelineEvents,
            scoreAway: displayGame.scoreAway,
            scoreHome: displayGame.scoreHome,
            awayTeam: displayGame.awayTeam,
            homeTeam: displayGame.homeTeam,
            flagSource: "GoingPro"
        )
        let cardTimelineSummary = LiveCardTimelineBuilder.buildSummary(
            sportType: displayGame.liveSportVisualType,
            timelineEvents: mergedTimelineEvents,
            homeTeam: displayGame.homeTeam,
            awayTeam: displayGame.awayTeam,
            gameId: displayGame.stableKey,
            provider: displayGame.source
        )
        return ProGameScoreBlock(
            awayTeam: displayGame.awayTeam,
            homeTeam: displayGame.homeTeam,
            awayScore: displayGame.scoreAway,
            homeScore: displayGame.scoreHome,
            awayBadgeURL: savedProGameTeamBadgeURL(for: displayGame, team: displayGame.awayTeam),
            homeBadgeURL: savedProGameTeamBadgeURL(for: displayGame, team: displayGame.homeTeam),
            source: "GoingPro",
            isFinal: isFinal,
            isLive: displayGame.matchStatus.isHappeningNow,
            accentColor: isFinal ? accent : FGColor.dangerRed,
            timelineSummary: timelineSummary?.hasContent == true ? timelineSummary : nil,
            cardTimelineSummary: cardTimelineSummary,
            gameId: displayGame.stableKey,
            showsFramedFinalBackground: isFinal
        )
        .frame(maxWidth: .infinity, alignment: .leading)
        .overlay {
            if isFinal {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .strokeBorder(accent.opacity(followingColorScheme == .dark ? 0.30 : 0.18), lineWidth: 1)
            }
        }
        .onAppear {
            logGoingProScorerRenderDebug(
                displayGame: displayGame,
                mergedTimelineEvents: mergedTimelineEvents,
                timelineSummary: timelineSummary,
                latestScoringEvent: nil
            )
        }
        .accessibilityLabel(isFinal ? "Final score \(displayGame.finalScoreSummary)" : displayGame.finalScoreSummary)
    }

    private func goingProMergedTimelineEvents(for displayGame: SavedProGame) -> [LiveTimelineEvent] {
        var byKey: [String: LiveTimelineEvent] = [:]
        for event in displayGame.timelineEvents ?? [] {
            byKey[event.id] = event
        }
        for match in goingProHydrationLiveMatches(for: displayGame) {
            for event in match.timelineEvents {
                byKey[event.id] = event
            }
        }
        return Array(byKey.values)
    }

    private func goingProHydrationLiveMatches(for displayGame: SavedProGame) -> [LiveMatch] {
        var matches: [LiveMatch] = []
        if let exact = viewModel.liveMatches.first(where: { SavedProGame.stableKey(for: $0) == displayGame.stableKey }) {
            matches.append(exact)
        }
        if let source = displayGame.source?.trimmingCharacters(in: .whitespacesAndNewlines), !source.isEmpty,
           let externalId = displayGame.externalId?.trimmingCharacters(in: .whitespacesAndNewlines), !externalId.isEmpty,
           let external = viewModel.liveMatches.first(where: {
               $0.source?.caseInsensitiveCompare(source) == .orderedSame
                   && $0.externalId?.caseInsensitiveCompare(externalId) == .orderedSame
           }),
           !matches.contains(where: { $0.id == external.id }) {
            matches.append(external)
        }
        return matches
    }

    private func goingProResolvedScorerTimelineSummary(
        for displayGame: SavedProGame,
        timelineEvents: [LiveTimelineEvent]
    ) -> LiveScoringTimelineSummary? {
        LiveScoringTimelineBuilder.resolvedGoalDisplaySummary(
            sportType: displayGame.liveSportVisualType,
            timelineEvents: timelineEvents,
            scoreAway: displayGame.scoreAway,
            scoreHome: displayGame.scoreHome,
            awayTeam: displayGame.awayTeam,
            homeTeam: displayGame.homeTeam,
            flagSource: "GoingPro"
        )
    }

    private func goingProResolvedLatestScoringEvent(
        for displayGame: SavedProGame,
        timelineEvents: [LiveTimelineEvent]
    ) -> LiveLatestScoringEvent? {
        if let latest = displayGame.latestScoringEvent {
            return latest
        }
        return LiveScoringEventResolver.resolve(
            sportType: displayGame.liveSportVisualType,
            timelineEvents: timelineEvents
        ).latestEvent
    }

    private func goingProResolvedFirstScoringEvent(
        for displayGame: SavedProGame,
        timelineEvents: [LiveTimelineEvent]
    ) -> LiveFirstScoringEvent? {
        LiveScoringTimelineBuilder.resolveFirstScoringEvent(
            sportType: displayGame.liveSportVisualType,
            timelineEvents: timelineEvents,
            homeTeam: displayGame.homeTeam,
            awayTeam: displayGame.awayTeam,
            scoreAway: displayGame.scoreAway,
            scoreHome: displayGame.scoreHome
        )
    }

    private func logGoingProScorerRenderDebug(
        displayGame: SavedProGame,
        mergedTimelineEvents: [LiveTimelineEvent],
        timelineSummary: LiveScoringTimelineSummary?,
        latestScoringEvent: LiveLatestScoringEvent?
    ) {
        let firstScoringEvent = goingProResolvedFirstScoringEvent(
            for: displayGame,
            timelineEvents: mergedTimelineEvents
        )
        let timelineSummaryEntriesCount = timelineSummary?.entries.count ?? 0
        let renderedGoalScorers = timelineSummaryEntriesCount > 0 || latestScoringEvent != nil
        let firstScoringEventText: String = {
            guard let firstScoringEvent else { return "nil" }
            let minute = firstScoringEvent.minuteText
                ?? firstScoringEvent.minute.map { "\($0)'" }
                ?? "nil"
            return "\(minute) \(firstScoringEvent.teamName)"
        }()
        let latestScoringEventText: String = {
            guard let latestScoringEvent else { return "nil" }
            let clock = latestScoringEvent.gameClock ?? "nil"
            let scorer = latestScoringEvent.scorer ?? "nil"
            return "\(clock) \(scorer)"
        }()
        print("[GoingProScorerRenderDebug] displayGame.id=\(displayGame.id)")
        print("[GoingProScorerRenderDebug] liveMatchId=\(displayGame.stableKey)")
        print("[GoingProScorerRenderDebug] timelineEventsRawCount=\(mergedTimelineEvents.count)")
        print("[GoingProScorerRenderDebug] timelineSummaryEntriesCount=\(timelineSummaryEntriesCount)")
        print("[GoingProScorerRenderDebug] firstScoringEvent=\(firstScoringEventText)")
        print("[GoingProScorerRenderDebug] latestScoringEvent=\(latestScoringEventText)")
        print("[GoingProScorerRenderDebug] renderedGoalScorers=\(renderedGoalScorers)")
    }

    private func savedProGameCardRefreshToken(_ displayGame: SavedProGame) -> String {
        let mergedTimelineEvents = goingProMergedTimelineEvents(for: displayGame)
        let renderedCount = goingProResolvedScorerTimelineSummary(
            for: displayGame,
            timelineEvents: mergedTimelineEvents
        )?.entries.count ?? 0
        let cardCount = LiveCardTimelineBuilder.cardEvents(
            sportType: displayGame.liveSportVisualType,
            timelineEvents: mergedTimelineEvents,
            homeTeam: displayGame.homeTeam,
            awayTeam: displayGame.awayTeam,
            gameId: displayGame.stableKey,
            provider: displayGame.source
        ).count
        return "\(displayGame.stableKey)|\(displayGame.matchStatus.rawValue)|\(displayGame.scoreAway)-\(displayGame.scoreHome)|\(displayGame.minute ?? -1)|\(mergedTimelineEvents.count)|\(renderedCount)|\(cardCount)"
    }

    private func savedProGameTeamBadgeURL(for game: SavedProGame, team: String) -> String? {
        if let match = viewModel.liveMatches.first(where: { SavedProGame.stableKey(for: $0) == game.stableKey }) {
            return match.badgeURL(forTeamName: team)
        }
        if let source = game.source?.trimmingCharacters(in: .whitespacesAndNewlines), !source.isEmpty,
           let externalId = game.externalId?.trimmingCharacters(in: .whitespacesAndNewlines), !externalId.isEmpty,
           let match = viewModel.liveMatches.first(where: {
               $0.source?.caseInsensitiveCompare(source) == .orderedSame
                   && $0.externalId?.caseInsensitiveCompare(externalId) == .orderedSame
           }) {
            return match.badgeURL(forTeamName: team)
        }
        return nil
    }

    private func statusTint(for game: SavedProGame, fallback: Color) -> Color {
        if game.matchStatus.isHappeningNow { return FGColor.dangerRed }
        if game.isFinal { return FGColor.mutedText(followingColorScheme) }
        return fallback
    }

    private var joinedGamesListContent: some View {
        let _: Void = logPickupPerfRender(mode: "Playing", rowCount: playingGameCards.count, renderPath: "LazyVStack+EquatableRenderCard")
        return LazyVStack(alignment: .leading, spacing: 12) {
            if viewModel.isPickupFollowingJoinListRefreshing && !playingGameCards.isEmpty {
                HStack(spacing: 8) {
                    ProgressView()
                        .scaleEffect(0.9)
                    Text("Refreshing games...")
                        .font(FGTypography.caption.weight(.medium))
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                }
                .padding(.horizontal, 4)
            }

            if playingGameCards.isEmpty {
                emptyCard(
                    icon: "figure.run",
                    title: "No games you’re playing yet.",
                    subtitle: "Join a game to see it here."
                )
            } else {
                ForEach(playingGameCards) { card in
                    EquatableRenderCard(token: pickupPlayingCardRenderToken(for: card)) {
                        pickupGameJoinCard(card)
                    }
                    .equatable()
                }
            }
        }
    }

    @ViewBuilder
    private var incomingPickupGameInvitesContent: some View {
        if !viewModel.incomingPickupGameInvites.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(viewModel.incomingPickupGameInvites) { item in
                    EquatableRenderCard(token: pickupInviteRenderToken(for: item)) {
                        pickupGameInviteCard(item)
                    }
                    .equatable()
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                }
            }
        }
    }

    private func pickupInviteRenderToken(for item: PickupGameInviteDisplay) -> PickupInviteRenderToken {
        PickupInviteRenderToken(
            id: item.id,
            game: item.game,
            inviterName: pickupInviteInviterName(item),
            inviterAvatarThumbnailURL: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_thumbnail_url),
            inviterAvatarURL: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_url),
            isBusy: pickupInviteResponseInFlightId == item.id,
            colorScheme: followingColorScheme
        )
    }

    private func pickupGameInviteCard(_ item: PickupGameInviteDisplay) -> some View {
        let game = item.game
        let inviterName = pickupInviteInviterName(item)
        let location = [game.address, game.city, game.state]
            .compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .joined(separator: ", ")
        let isBusy = pickupInviteResponseInFlightId == item.id

        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                pickupInviteInviterAvatar(item, size: 40)

                VStack(alignment: .leading, spacing: 3) {
                    Text("\(inviterName) invited you")
                        .font(FGTypography.caption.weight(.semibold))
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    HStack(alignment: .top, spacing: 8) {
                        SportArtworkIconView(sport: game.sport, diameter: 30)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(game.title)
                                .font(FGTypography.cardTitle)
                                .foregroundStyle(FGColor.primaryText(followingColorScheme))
                                .lineLimit(2)
                            GameFormatBadgeView(format: game.gameFormat, colorScheme: followingColorScheme)
                        }
                    }
                }
                Spacer(minLength: 0)
            }

            if let dateLine = game.pickupDateWithCompactTimeRange {
                Label(dateLine, systemImage: "calendar")
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
            }
            if !location.isEmpty {
                Label(location, systemImage: "mappin.and.ellipse")
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .lineLimit(2)
            }
            Label(spotsOpenLine(for: game), systemImage: "person.3")
                .font(FGTypography.caption.weight(.semibold))
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))

            Button {
                followingPickupInviteDetail = item
            } label: {
                HStack(spacing: 6) {
                    Text("View invite details")
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .bold))
                }
                .font(FGTypography.caption.weight(.semibold))
                .foregroundStyle(FGColor.accentBlue)
            }
            .buttonStyle(.plain)

            HStack(spacing: 8) {
                pickupInviteResponseButton("Accept", tint: FGColor.accentGreen, disabled: isBusy) {
                    await respondToPickupInvite(item, status: "accepted")
                }
                pickupInviteResponseButton("Maybe", tint: Color.orange, disabled: isBusy) {
                    await respondToPickupInvite(item, status: "maybe")
                }
                pickupInviteResponseButton("Decline", tint: Color.red.opacity(0.9), disabled: isBusy) {
                    await respondToPickupInvite(item, status: "declined")
                }
            }
        }
        .padding(14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(Color.orange.opacity(followingColorScheme == .dark ? 0.38 : 0.24), lineWidth: 1)
        )
        .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .onTapGesture {
            followingPickupInviteDetail = item
        }
    }

    private func pickupInviteResponseButton(
        _ title: String,
        tint: Color,
        disabled: Bool,
        action: @escaping () async -> Void
    ) -> some View {
        Button {
            Task { await action() }
        } label: {
            if disabled {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
            } else {
                Text(title)
                    .font(FGTypography.metadata.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
            }
        }
        .buttonStyle(.bordered)
        .tint(tint)
        .disabled(disabled)
    }

    private func respondToPickupInvite(_ item: PickupGameInviteDisplay, status: String) async {
        pickupInviteResponseInFlightId = item.id
        let priorInvites = viewModel.incomingPickupGameInvites
        withAnimation(.spring(response: 0.3, dampingFraction: 0.86)) {
            viewModel.incomingPickupGameInvites.removeAll { $0.id == item.id }
        }
        if status.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "accepted" {
            FGInteractionHaptics.success()
        } else {
            FGInteractionHaptics.selection()
        }
        defer {
            pickupInviteResponseInFlightId = nil
            if viewModel.incomingPickupGameInvites.isEmpty && priorInvites.count > 1 {
                Task { await viewModel.loadIncomingPickupGameInvites() }
            }
        }
        await viewModel.respondToPickupGameInvite(item.invite, status: status)
    }

    private func pickupInviteInviterAvatar(_ item: PickupGameInviteDisplay, size: CGFloat) -> some View {
        UserAvatarView(
            avatarThumbnailURL: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_thumbnail_url),
            avatarURL: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_url),
            avatarDisplayRefreshToken: UserAvatarView.stableRefreshToken(
                userId: item.invite.inviter_user_id,
                thumbnailURL: item.inviterProfile?.avatar_thumbnail_url,
                avatarURL: item.inviterProfile?.avatar_url
            ),
            displayName: pickupInviteInviterName(item),
            email: item.inviterProfile?.email ?? "",
            size: size,
            fallbackStyle: followingColorScheme == .dark ? .darkCardTranslucent : .lightOnWhiteChrome
        )
    }

    private func pickupInviteInviterName(_ item: PickupGameInviteDisplay) -> String {
        let display = item.inviterProfile?.display_name?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !display.isEmpty { return display }
        let username = item.inviterProfile?.username?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !username.isEmpty { return username }
        return "A friend"
    }

    private func spotsOpenLine(for game: PickupGameRow) -> String {
        let open = game.pickupOpenSlotsRemaining
        if open == 1 { return "1 spot open" }
        return "\(open) spots open"
    }

    private var hostedGamesListContent: some View {
        let hostingRowCount = goingPickupHostingGamesForDisplay.count + viewModel.myRemovedPickupGamesForSettings.count
        let _: Void = logPickupPerfRender(mode: "Hosting", rowCount: hostingRowCount, renderPath: "LazyVStack+EquatableRenderCard")
        return LazyVStack(alignment: .leading, spacing: 12) {
            if goingPickupHostingGamesForDisplay.isEmpty, viewModel.myRemovedPickupGamesForSettings.isEmpty {
                hostingEmptyStateCard
            } else {
                ForEach(goingPickupHostingGamesForDisplay) { row in
                    let pendingHere = viewModel.organizerPendingPickupJoinRequests(for: row.id)
                    let withdrawnRows = viewModel.pickupOrganizerWithdrawnRequestsByGameId[row.id] ?? []
                    EquatableRenderCard(
                        token: PickupHostedCardRenderToken(
                            row: row,
                            pendingJoinCount: pendingHere,
                            withdrawnJoinRows: withdrawnRows,
                            now: followingMyPickupClockTick,
                            colorScheme: followingColorScheme
                        )
                    ) {
                        SettingsPickupMyGameListCard(
                            viewModel: viewModel,
                            row: row,
                            pendingJoinCount: pendingHere,
                            withdrawnJoinRows: withdrawnRows,
                            now: followingMyPickupClockTick,
                            colorScheme: followingColorScheme,
                            onEdit: {
                                logFollowingMyPickupGames(action: "editTap", selectedGameId: row.id)
                                followingMyPickupFormMode = .edit(row)
                            },
                            onDelete: {
                                logFollowingMyPickupGames(action: "cancelGameTap", selectedGameId: row.id)
                                followingMyPickupDeleteTarget = row
                            },
                            onManageRequests: {
                                logFollowingMyPickupGames(action: "manageRequestsTap", selectedGameId: row.id)
                                followingMyPickupOrganizerRequestsGame = row
                            },
                            displayStyle: .followingCompact,
                            onOpenDetails: {
                                logFollowingMyPickupGames(action: "openDetailSheet", selectedGameId: row.id)
                                followingMyPickupDetailGame = row
                            },
                            onInvite: {
                                logFollowingMyPickupGames(action: "inviteTap", selectedGameId: row.id)
                                followingPickupInviteGame = row
                            },
                            onOpenMap: {
                                openHostedPickupGameOnDiscoverMap(row)
                            }
                        )
                        .environmentObject(chatViewModel)
                    }
                    .equatable()
                }

                if !viewModel.myRemovedPickupGamesForSettings.isEmpty {
                    Text("History")
                        .font(FGTypography.caption.weight(.semibold))
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.top, 4)
                    ForEach(viewModel.myRemovedPickupGamesForSettings) { row in
                        SettingsPickupRemovedHistoryCard(
                            viewModel: viewModel,
                            row: row,
                            withdrawnJoinRows: viewModel.pickupOrganizerWithdrawnRequestsByGameId[row.id] ?? [],
                            now: followingMyPickupClockTick,
                            colorScheme: followingColorScheme,
                            useCompactCopy: true
                        )
                    }
                }
            }
        }
    }

    private func pickupPlayingCardRenderToken(for card: PickupGameJoinRequestCardDisplay) -> PickupPlayingCardRenderToken {
        let resolvedGame = viewModel.resolvedPickupGameRow(for: card.pickupGameId)
        return PickupPlayingCardRenderToken(
            card: card,
            resolvedGame: resolvedGame,
            organizerAvatarThumbnailURL: viewModel.pickupOrganizerAvatarThumbnailForDetail(userId: card.organizerUserId),
            organizerAvatarURL: viewModel.pickupOrganizerAvatarFullForDetail(userId: card.organizerUserId),
            organizerAvatarRefreshToken: viewModel.pickupOrganizerAvatarRefreshTokenForDetail(userId: card.organizerUserId),
            organizerEmail: viewModel.pickupOrganizerEmailForDetail(userId: card.organizerUserId),
            currentUserId: viewModel.currentUserAuthId,
            hasUnreadActivity: viewModel.pickupFollowingUnreadActivityGameIds.contains(card.pickupGameId),
            isRefreshSpinning: viewModel.pickupFollowingCardRefreshSpinGameId == card.pickupGameId,
            isWithdrawInFlight: followingPickupWithdrawInFlight,
            lastJoinStatusRefreshAt: viewModel.lastJoinStatusRefreshAt,
            colorScheme: followingColorScheme
        )
    }

    private var hostingEmptyStateCard: some View {
        VStack(spacing: 12) {
            Image(systemName: "sportscourt.fill")
                .font(.largeTitle)
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))

            Text("No games you’re hosting yet.")
                .font(FGTypography.cardTitle)
                .foregroundStyle(FGColor.primaryText(followingColorScheme))

            Text("Create a game when you’re ready to play.")
                .font(FGTypography.caption)
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                .multilineTextAlignment(.center)

            Button {
                openCreatePickupFromGoing()
            } label: {
                Text("Create Game")
                    .font(FGTypography.metadata.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)
            .tint(FGColor.accentGreen)
            .padding(.top, 2)
            .accessibilityLabel("Create Game")
        }
        .frame(maxWidth: .infinity)
        .padding(18)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
    }

    // MARK: - Session / cache (Following tab only)

    private func clearFollowingUserSpecificState() {
        viewModel.clearFollowingTabCaches()
        viewModel.favoriteVenueIDs = []
        viewModel.venueEventInterestIDs = []
        viewModel.interestedVenueEventKeys = []
        viewModel.incomingPickupGameInvites = []
        viewModel.favoriteTeamProGames = []
        viewModel.clearBusinessFavoriteTeamState()
    }

    private func reloadFollowingDataForCurrentUser() async {
        if isBusinessProGamesOnly {
            await reloadBusinessProGamesData(reason: "authOrInitialReload")
            return
        }
        await viewModel.fetchSavedProGames(reason: "authOrInitialReload")
        await viewModel.refreshFollowingTabDataGloballyUnlessFresh()
        await viewModel.loadMyPickupGameJoinRequestsForFollowing(
            reason: "authOrInitialReload"
        )
        await viewModel.loadIncomingPickupGameInvites()
        await refreshFavoriteTeamProGames(reason: "authOrInitialReload")
    }

    private func reloadBusinessProGamesData(reason: String) async {
        sanitizeBusinessGoingModeIfNeeded()
        if reason == "pullToRefresh" {
            await viewModel.refreshGoingProGames(reason: reason)
        } else {
            await viewModel.fetchSavedProGames(reason: reason)
        }
        if let businessId = await MainActor.run(body: { viewModel.currentBusinessIdForAddLocation() }) {
            await viewModel.loadBusinessFavoriteTeams(businessId: businessId)
        }
        await refreshBusinessFavoriteTeamProGames(reason: reason, forceRefresh: reason == "pullToRefresh")
    }

#if DEBUG
    private func logFollowingMyPickupGames(action: String, selectedGameId: UUID? = nil) {
        let active = viewModel.myPickupGamesForSettings.count
        let hist = viewModel.myRemovedPickupGamesForSettings.count
        print("[FollowingMyPickupGames] loadedCount=\(active + hist)")
        print("[FollowingMyPickupGames] activeCount=\(active)")
        print("[FollowingMyPickupGames] historyCount=\(hist)")
        if let id = selectedGameId {
            print("[FollowingMyPickupGames] selectedGameId=\(id.uuidString.lowercased())")
        } else {
            print("[FollowingMyPickupGames] selectedGameId=")
        }
        print("[FollowingMyPickupGames] action=\(action)")
    }
#else
    private func logFollowingMyPickupGames(action: String, selectedGameId: UUID? = nil) {
        _ = action
        _ = selectedGameId
    }
#endif

    private func logPickupPerfRender(mode: String, rowCount: Int, renderPath: String) {
#if DEBUG
        print("[PickupPerf] screen=Going mode=\(mode) rowCount=\(rowCount) renderPath=\(renderPath) freshnessSkip=false forcedReload=false")
#else
        _ = mode
        _ = rowCount
        _ = renderPath
#endif
    }

    private func openCreatePickupFromGoing() {
        guard viewModel.canFanUsePickupGamesUI else { return }
        logGoingHubDebug(reason: "createPickupTapped", createPickupTapped: true)
        followingMyPickupFormMode = .add
    }

    private func openHostedPickupGameOnDiscoverMap(_ row: PickupGameRow) {
        logFollowingMyPickupGames(action: "openMap", selectedGameId: row.id)
        viewModel.requestDiscoverFocusForPickupGame(id: row.id, snapshot: row)
    }

    private func openPlayingPickupGameOnDiscoverMap(_ card: PickupGameJoinRequestCardDisplay) {
        logFollowingMyPickupGames(action: "openPlayingMap", selectedGameId: card.pickupGameId)
        viewModel.requestDiscoverFocusForPickupGame(
            id: card.pickupGameId,
            snapshot: viewModel.resolvedPickupGameRow(for: card.pickupGameId)
        )
    }

#if DEBUG
    private func logGoingHubDebug(reason: String, createPickupTapped: Bool = false) {
        print("[GoingStructureDebug] venueGamesGoingCount=\(goingVenueGameItems.count)")
        print("[GoingStructureDebug] favoriteVenuesCount=\(viewModel.followingTabSavedVenues.count)")
        print("[GoingStructureDebug] pickupPlayingCount=\(viewModel.myPickupGameJoinRequestCards.count)")
        print("[GoingStructureDebug] pickupHostingCount=\(viewModel.myPickupGamesForSettings.count)")
        print("[GoingStructureDebug] hostPickupTapped=\(createPickupTapped)")
        let emptySections = goingStructureEmptySections()
        if emptySections.isEmpty {
            print("[GoingStructureDebug] sectionEmptyState=none")
        } else {
            for section in emptySections {
                print("[GoingStructureDebug] sectionEmptyState=\(section)")
            }
        }
        print("[GoingStructureDebug] reason=\(reason)")
    }
#else
    private func logGoingHubDebug(reason: String, createPickupTapped: Bool = false) {
        _ = reason
        _ = createPickupTapped
    }
#endif

    private func goingStructureEmptySections() -> [String] {
        var sections: [String] = []
        if goingVenueGameItems.isEmpty { sections.append("I’m Going") }
        if viewModel.followingTabSavedVenues.isEmpty { sections.append("Saved") }
        if viewModel.myPickupGameJoinRequestCards.isEmpty { sections.append("Playing") }
        if viewModel.myPickupGamesForSettings.isEmpty { sections.append("Hosting") }
        return sections
    }

    private func scheduleFollowingMyPickupExpiryRefreshIfNeeded(now: Date) {
        guard !followingMyPickupDidScheduleExpiryRefresh else { return }
        let rows = viewModel.myPickupGamesForSettings + viewModel.myRemovedPickupGamesForSettings
        let anyPast = rows.contains { row in
            guard let deadline = row.pickupHistoryClientCleanupDeadline() else { return false }
            return now >= deadline
        }
        guard anyPast else { return }
        followingMyPickupDidScheduleExpiryRefresh = true
        Task {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            await viewModel.loadMyPickupGamesForSettings(forceRefresh: true, reason: "followingPostCleanupDeadline")
            logFollowingMyPickupGames(action: "postCleanupDeadlineRefresh")
        }
    }

    private func performFollowingMyPickupDelete(_ row: PickupGameRow) async {
        do {
            try await viewModel.deletePickupGame(id: row.id)
            followingMyPickupBanner = nil
            await viewModel.loadMyPickupGamesForSettings(forceRefresh: true, reason: "followingDeleteSuccess")
            await viewModel.refreshPickupGamesForDiscoverMap(force: true)
            logFollowingMyPickupGames(action: "deleteGameSuccess", selectedGameId: row.id)
        } catch {
            followingMyPickupBanner = error.localizedDescription
            logFollowingMyPickupGames(action: "deleteGameFailed", selectedGameId: row.id)
        }
    }

    // MARK: - Attendance actions

    private func setInterestedOnlyLocally(_ venueEventID: UUID, _ add: Bool) {
        var set = decodeInterestedOnlyUUIDs(from: interestedOnlyEncoded)
        if add {
            set.insert(venueEventID)
        } else {
            set.remove(venueEventID)
        }
        interestedOnlyEncoded = encodeInterestedOnlyUUIDs(set)
    }

    @MainActor
    private func applyAttendance(_ item: FollowingGoingDisplayItem, target: FollowingAttendanceTarget) async {
        guard viewModel.isAuthenticatedForSocialFeatures else { return }

        let previousInterestedOnly = interestedOnlyEncoded
        let previousGoingItems = viewModel.followingTabGoingItems
        let previousCachedGoingItems = cachedGoingVenueGameItems
        let previousGoingInterestCounts = viewModel.followingTabGoingInterestCounts
        let previousServerGoingIDs = viewModel.followingTabUserVenueEventInterestIDs
        let oldStatus = item.goingTabStatusDebugValue
        let newStatus = target.goingTabStatusDebugValue
        var ok = true

#if DEBUG
        print("[FollowingState] attendance action event=\(item.id.uuidString) action=\(target)")
#endif

        switch target {
        case .going:
            if item.isServerGoing && !item.isInterestedOnlyLocal {
                logGoingTabStatusDebug(
                    eventID: item.id,
                    oldStatus: oldStatus,
                    newStatus: newStatus,
                    includedInGoingTab: true,
                    optimisticUpdate: false,
                    backendSaved: true
                )
                logGoingStatusOptimistic(
                    before: oldStatus,
                    after: newStatus,
                    eventID: item.id,
                    localUpdated: false,
                    backendSynced: true,
                    rollback: false
                )
                return
            }
            setInterestedOnlyLocally(item.id, false)
            applyOptimisticGoingTabAttendance(item, target: target)
            logGoingStatusOptimistic(
                before: oldStatus,
                after: newStatus,
                eventID: item.id,
                localUpdated: true,
                backendSynced: nil,
                rollback: false
            )
            logGoingTabStatusDebug(
                eventID: item.id,
                oldStatus: oldStatus,
                newStatus: newStatus,
                includedInGoingTab: true,
                optimisticUpdate: true,
                backendSaved: nil
            )
            ok = await syncGoingStatusToBackend(eventID: item.id, isGoing: true)
        case .interested:
            if !item.isServerGoing && item.isInterestedOnlyLocal {
                logGoingTabStatusDebug(
                    eventID: item.id,
                    oldStatus: oldStatus,
                    newStatus: newStatus,
                    includedInGoingTab: true,
                    optimisticUpdate: false,
                    backendSaved: true
                )
                logGoingStatusOptimistic(
                    before: oldStatus,
                    after: newStatus,
                    eventID: item.id,
                    localUpdated: false,
                    backendSynced: true,
                    rollback: false
                )
                return
            }
            setInterestedOnlyLocally(item.id, true)
            applyOptimisticGoingTabAttendance(item, target: target)
            logGoingStatusOptimistic(
                before: oldStatus,
                after: newStatus,
                eventID: item.id,
                localUpdated: true,
                backendSynced: nil,
                rollback: false
            )
            logGoingTabStatusDebug(
                eventID: item.id,
                oldStatus: oldStatus,
                newStatus: newStatus,
                includedInGoingTab: true,
                optimisticUpdate: true,
                backendSaved: nil
            )
            if item.isServerGoing {
                ok = await syncGoingStatusToBackend(eventID: item.id, isGoing: false)
            }
        case .notGoing:
            guard item.isActiveGoingTabPlan else {
                logGoingTabStatusDebug(
                    eventID: item.id,
                    oldStatus: oldStatus,
                    newStatus: newStatus,
                    includedInGoingTab: false,
                    optimisticUpdate: false,
                    backendSaved: true
                )
                logGoingStatusOptimistic(
                    before: oldStatus,
                    after: newStatus,
                    eventID: item.id,
                    localUpdated: false,
                    backendSynced: true,
                    rollback: false
                )
                return
            }
            setInterestedOnlyLocally(item.id, false)
            applyOptimisticGoingTabAttendance(item, target: target)
            logGoingStatusOptimistic(
                before: oldStatus,
                after: newStatus,
                eventID: item.id,
                localUpdated: true,
                backendSynced: nil,
                rollback: false
            )
            logGoingTabStatusDebug(
                eventID: item.id,
                oldStatus: oldStatus,
                newStatus: newStatus,
                includedInGoingTab: false,
                optimisticUpdate: true,
                backendSaved: nil
            )
            if item.isServerGoing {
                ok = await syncGoingStatusToBackend(eventID: item.id, isGoing: false)
            }
        }

        guard ok else {
#if DEBUG
            print("[FollowingState] attendance update failed event=\(item.id.uuidString) action=\(target)")
#endif
            interestedOnlyEncoded = previousInterestedOnly
            viewModel.followingTabGoingItems = previousGoingItems
            cachedGoingVenueGameItems = previousCachedGoingItems
            viewModel.followingTabGoingInterestCounts = previousGoingInterestCounts
            viewModel.followingTabUserVenueEventInterestIDs = previousServerGoingIDs
            viewModel.refreshFollowingInterestDerivedSnapshotsForUI()
            logGoingStatusOptimistic(
                before: oldStatus,
                after: newStatus,
                eventID: item.id,
                localUpdated: false,
                backendSynced: false,
                rollback: true
            )
            logGoingTabStatusDebug(
                eventID: item.id,
                oldStatus: oldStatus,
                newStatus: newStatus,
                includedInGoingTab: item.isActiveGoingTabPlan,
                optimisticUpdate: false,
                backendSaved: false
            )
            viewModel.showSocialActionToast("Couldn't update your game plan.")
            return
        }
        logGoingTabStatusDebug(
            eventID: item.id,
            oldStatus: oldStatus,
            newStatus: newStatus,
            includedInGoingTab: target.isIncludedInGoingTab,
            optimisticUpdate: false,
            backendSaved: true
        )
        logGoingStatusOptimistic(
            before: oldStatus,
            after: newStatus,
            eventID: item.id,
            localUpdated: true,
            backendSynced: true,
            rollback: false
        )
#if DEBUG
        switch target {
        case .going:
            print("[FollowingState] marked going")
        case .interested:
            print("[FollowingState] marked interested")
        case .notGoing:
            print("[FollowingState] marked not going, removed from following")
        }
#endif
    }

    private func syncGoingStatusToBackend(eventID: UUID, isGoing: Bool) async -> Bool {
        await viewModel.setVenueEventInterest(
            venueEventID: eventID,
            isInterested: isGoing,
            refreshFollowing: false,
            applyOptimistic: false,
            manageWriteInFlight: true,
            schedulePostWriteRefreshes: false,
            applyLocalSuccessState: false
        )
    }

    @MainActor
    private func applyOptimisticGoingTabAttendance(_ item: FollowingGoingDisplayItem, target: FollowingAttendanceTarget) {
        let attendeeCount = optimisticAttendeeCount(for: item, target: target)
        switch target {
        case .going:
            viewModel.followingTabUserVenueEventInterestIDs.insert(item.id)
            upsertOptimisticGoingTabItem(
                item,
                attendeeCount: attendeeCount,
                isServerGoing: true,
                isInterestedOnlyLocal: false
            )
        case .interested:
            viewModel.followingTabUserVenueEventInterestIDs.remove(item.id)
            upsertOptimisticGoingTabItem(
                item,
                attendeeCount: attendeeCount,
                isServerGoing: false,
                isInterestedOnlyLocal: true
            )
        case .notGoing:
            viewModel.followingTabUserVenueEventInterestIDs.remove(item.id)
            viewModel.followingTabGoingItems.removeAll { $0.id == item.id }
            cachedGoingVenueGameItems.removeAll { $0.id == item.id }
        }
        applyOptimisticGoingTabInterestCount(eventID: item.id, attendeeCount: attendeeCount)
        viewModel.followingTabGoingItems = MapViewModel.sortFollowingGoingItemsChronologically(viewModel.followingTabGoingItems)
        cachedGoingVenueGameItems = MapViewModel.sortFollowingGoingItemsChronologically(cachedGoingVenueGameItems)
        viewModel.refreshFollowingInterestDerivedSnapshotsForUI()
    }

    @MainActor
    private func upsertOptimisticGoingTabItem(
        _ item: FollowingGoingDisplayItem,
        attendeeCount: Int,
        isServerGoing: Bool,
        isInterestedOnlyLocal: Bool
    ) {
        let updated = FollowingGoingDisplayItem(
            id: item.id,
            venueEvent: item.venueEvent,
            bar: item.bar,
            attendeeCount: attendeeCount,
            isServerGoing: isServerGoing,
            isInterestedOnlyLocal: isInterestedOnlyLocal
        )
        if let index = viewModel.followingTabGoingItems.firstIndex(where: { $0.id == item.id }) {
            viewModel.followingTabGoingItems[index] = updated
        } else {
            viewModel.followingTabGoingItems.append(updated)
        }
        if let index = cachedGoingVenueGameItems.firstIndex(where: { $0.id == item.id }) {
            cachedGoingVenueGameItems[index] = updated
        } else {
            cachedGoingVenueGameItems.append(updated)
        }
    }

    private func optimisticAttendeeCount(for item: FollowingGoingDisplayItem, target: FollowingAttendanceTarget) -> Int {
        switch target {
        case .going:
            return item.isServerGoing ? item.attendeeCount : max(item.attendeeCount + 1, 1)
        case .interested:
            return item.isServerGoing ? max(item.attendeeCount - 1, 0) : item.attendeeCount
        case .notGoing:
            return item.isServerGoing ? max(item.attendeeCount - 1, 0) : item.attendeeCount
        }
    }

    @MainActor
    private func applyOptimisticGoingTabInterestCount(eventID: UUID, attendeeCount: Int) {
        if attendeeCount > 0 {
            viewModel.followingTabGoingInterestCounts[eventID] = attendeeCount
        } else {
            viewModel.followingTabGoingInterestCounts.removeValue(forKey: eventID)
        }
    }

    private func logGoingTabStatusDebug(
        eventID: UUID,
        oldStatus: String,
        newStatus: String,
        includedInGoingTab: Bool,
        optimisticUpdate: Bool,
        backendSaved: Bool?
    ) {
#if DEBUG
        print("[GoingTabStatusDebug] eventID=\(eventID.uuidString.lowercased())")
        print("[GoingTabStatusDebug] oldStatus=\(oldStatus)")
        print("[GoingTabStatusDebug] newStatus=\(newStatus)")
        print("[GoingTabStatusDebug] includedInGoingTab=\(includedInGoingTab)")
        print("[GoingTabStatusDebug] optimisticUpdate=\(optimisticUpdate)")
        print("[GoingTabStatusDebug] backendSaved=\(backendSaved.map { String($0) } ?? "pending")")
#endif
    }

    private func logGoingStatusOptimistic(
        before: String,
        after: String,
        eventID: UUID,
        localUpdated: Bool,
        backendSynced: Bool?,
        rollback: Bool
    ) {
#if DEBUG
        print("[GoingStatusOptimistic] before=\(before) after=\(after) eventId=\(eventID.uuidString.lowercased()) localUpdated=\(localUpdated) backendSynced=\(backendSynced.map { String($0) } ?? "pending") rollback=\(rollback)")
#endif
    }

    // MARK: - Shared UI pieces

    private func pickupGameJoinCard(_ card: PickupGameJoinRequestCardDisplay) -> some View {
        let resolvedGame = viewModel.resolvedPickupGameRow(for: card.pickupGameId)
        let sportVisual = SportFilterCatalog.resolve(card.sport)
        let now = Date()
        let pickupStarted = resolvedGame?.hasPickupGameStarted(now: now)
            ?? PickupGameModels.parseSupabaseTimestamptz(card.game_start_at).map { now >= $0 }
            ?? false
        let isOrganizerCanceled = card.pill == .canceledByOrganizer
        let isRejected = card.pill == .declined
        let openMap = {
            openPlayingPickupGameOnDiscoverMap(card)
        }

        return VStack(alignment: .leading, spacing: FGSpacing.sm) {
            HStack(alignment: .top, spacing: FGSpacing.sm) {
                PickupGameStartedSportGlyphFrame(showStarted: pickupStarted) {
                    Image(systemName: sportVisual.systemImage)
                        .font(.title2.weight(.semibold))
                        .foregroundStyle(sportVisual.accent)
                        .frame(width: 40, height: 40)
                        .background(sportVisual.accent.opacity(0.14), in: Circle())
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text(card.title)
                        .font(FGTypography.cardTitle)
                        .foregroundStyle(FGColor.primaryText(followingColorScheme))
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                    GameFormatBadgeView(
                        format: resolvedGame?.gameFormat ?? .pickup,
                        colorScheme: followingColorScheme
                    )
                    pickupJoinStatusPill(card.pill)
                    if isOrganizerCanceled {
                        Text("Canceled by organizer")
                            .font(FGTypography.caption.weight(.semibold))
                            .foregroundStyle(Color.red.opacity(followingColorScheme == .dark ? 0.9 : 0.78))
                            .fixedSize(horizontal: false, vertical: true)
                        Text(viewModel.pickupHistoryAutoClearCaption(forPickupGameId: card.pickupGameId))
                            .font(FGTypography.caption)
                            .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                            .fixedSize(horizontal: false, vertical: true)
                    } else if isRejected {
                        Text("The organizer declined this request. You can clear it from your Playing list.")
                            .font(FGTypography.caption)
                            .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 0)
            }
            .contentShape(Rectangle())
            .onTapGesture(perform: openMap)

            if !card.dateTimeLine.isEmpty {
                Label(card.dateTimeLine, systemImage: "calendar")
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .labelStyle(.titleAndIcon)
                    .contentShape(Rectangle())
                    .onTapGesture(perform: openMap)
                if pickupStarted {
                    PickupGameStartedLineCaption()
                        .contentShape(Rectangle())
                        .onTapGesture(perform: openMap)
                }
            }
            if !card.locationLine.isEmpty {
                Label(card.locationLine, systemImage: "mappin.and.ellipse")
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .lineLimit(2)
                    .labelStyle(.titleAndIcon)
                    .contentShape(Rectangle())
                    .onTapGesture(perform: openMap)
            }

            HStack(spacing: FGSpacing.sm) {
                PublicProfileAvatarTap(userId: card.organizerUserId, context: "following_pickup_organizer") {
                    UserAvatarView(
                        avatarThumbnailURL: viewModel.pickupOrganizerAvatarThumbnailForDetail(userId: card.organizerUserId),
                        avatarURL: viewModel.pickupOrganizerAvatarFullForDetail(userId: card.organizerUserId),
                        avatarDisplayRefreshToken: viewModel.pickupOrganizerAvatarRefreshTokenForDetail(userId: card.organizerUserId),
                        displayName: card.organizerName,
                        email: viewModel.pickupOrganizerEmailForDetail(userId: card.organizerUserId),
                        size: 36,
                        fallbackStyle: followingColorScheme == .dark ? .darkCardTranslucent : .lightOnWhiteChrome
                    )
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Organizer")
                        .font(FGTypography.metadata)
                        .foregroundStyle(FGColor.mutedText(followingColorScheme))
                    Text(card.organizerName)
                        .font(FGTypography.caption)
                        .fontWeight(.semibold)
                        .foregroundStyle(FGColor.primaryText(followingColorScheme))
                }
                Spacer(minLength: 0)
            }

            // TODO(Organizer Reputation): Re-enable organizer rating/review presentation here
            // when reputation includes average rating, total reviews, reliability score,
            // organizer badges, and profile reputation display.

            if let spots = card.spotsRemainingSummary, !spots.isEmpty, !isOrganizerCanceled {
                Text(spots)
                    .font(FGTypography.metadata)
                    .foregroundStyle(FGColor.mutedText(followingColorScheme))
                    .contentShape(Rectangle())
                    .onTapGesture(perform: openMap)
            }

            if card.pill == .pending || card.pill == .approved || isRejected {
                Group {
                    if card.pill == .pending {
                        Button(role: .destructive) {
                            let rid = viewModel.pickupJoinRequestLatestByPickupGameIdForFan[card.pickupGameId]?.id ?? card.id
#if DEBUG
                            print("[PickupJoinWithdraw] tapped gameId=\(card.pickupGameId.uuidString.lowercased())")
                            print("[PickupJoinWithdraw] requestId=\(rid.uuidString.lowercased())")
#endif
                            followingPickupWithdrawConfirm = PickupJoinWithdrawConfirmState(
                                requestId: rid,
                                pickupGameId: card.pickupGameId,
                                intent: .pending
                            )
                        } label: {
                            Text("Withdraw request")
                                .font(FGTypography.metadata.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                        }
                        .buttonStyle(.bordered)
                        .tint(Color.red.opacity(0.92))
                        .disabled(followingPickupWithdrawInFlight)
                    } else if card.pill == .approved {
                        Button(role: .destructive) {
                            let rid = viewModel.pickupJoinRequestLatestByPickupGameIdForFan[card.pickupGameId]?.id ?? card.id
#if DEBUG
                            print("[PickupJoinWithdraw] tapped gameId=\(card.pickupGameId.uuidString.lowercased())")
                            print("[PickupJoinWithdraw] requestId=\(rid.uuidString.lowercased())")
#endif
                            followingPickupWithdrawConfirm = PickupJoinWithdrawConfirmState(
                                requestId: rid,
                                pickupGameId: card.pickupGameId,
                                intent: .approved
                            )
                        } label: {
                            Text("Can’t make it")
                                .font(FGTypography.metadata.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                        }
                        .buttonStyle(.bordered)
                        .tint(Color.red.opacity(0.92))
                        .disabled(followingPickupWithdrawInFlight)
                    } else {
                        Button {
                            viewModel.markPickupFollowingRejectedRequestCleared(
                                requestId: card.id,
                                pickupGameId: card.pickupGameId
                            )
                        } label: {
                            Text("Clear")
                                .font(FGTypography.metadata.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                        }
                        .buttonStyle(.bordered)
                        .tint(Color.gray.opacity(0.9))
                    }
                }
                .padding(.top, 4)
            }

            HStack(alignment: .center, spacing: FGSpacing.sm) {
                if !isOrganizerCanceled {
                    if let at = viewModel.lastJoinStatusRefreshAt {
                        Label {
                            Text("Updated \(at.formatted(date: .abbreviated, time: .shortened))")
                        } icon: {
                            Image(systemName: "clock.arrow.circlepath")
                        }
                        .font(FGTypography.caption)
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                        .lineLimit(1)
                        .minimumScaleFactor(0.85)
                    } else {
                        Label("Sync pending", systemImage: "clock")
                            .font(FGTypography.caption)
                            .foregroundStyle(FGColor.mutedText(followingColorScheme))
                    }
                    Spacer(minLength: 0)
                    if viewModel.pickupFollowingUnreadActivityGameIds.contains(card.pickupGameId) {
                        Circle()
                            .fill(Color.orange.opacity(0.9))
                            .frame(width: 8, height: 8)
                            .accessibilityLabel("Pickup activity")
                    }
                    Button {
                        Task { await viewModel.refreshPickupFollowingJoinCard(pickupGameId: card.pickupGameId) }
                    } label: {
                        if viewModel.pickupFollowingCardRefreshSpinGameId == card.pickupGameId {
                            ProgressView()
                                .scaleEffect(0.85)
                        } else {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(Color.orange.opacity(0.95))
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Refresh pickup status")
                } else {
                    Spacer(minLength: 0)
                }
            }
            .padding(.top, 2)

            if isOrganizerCanceled {
                HStack(spacing: FGSpacing.sm) {
                    Button {
                        viewModel.markPickupFollowingOrganizerCanceledCardUserCleared(pickupGameId: card.pickupGameId)
                    } label: {
                        Text("Clear now")
                            .font(FGTypography.metadata.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.bordered)
                    .tint(Color.red.opacity(0.88))

                    Button {
                        pickupDetailNav = PickupDetailNavigationToken(id: card.pickupGameId)
                    } label: {
                        Text("View details")
                            .font(FGTypography.metadata.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.bordered)
                    .tint(FGColor.accentBlue)
                }
            } else {
                Button {
                    pickupDetailNav = PickupDetailNavigationToken(id: card.pickupGameId)
                } label: {
                    Text("View Details")
                        .font(FGTypography.caption)
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                }
                .buttonStyle(.borderedProminent)
                .tint(FGColor.accentBlue)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            ZStack {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(.ultraThinMaterial)
                if isOrganizerCanceled || isRejected {
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: [
                                    (isOrganizerCanceled ? Color.red : Color.gray).opacity(followingColorScheme == .dark ? 0.22 : 0.12),
                                    (isOrganizerCanceled ? Color.red : Color.gray).opacity(followingColorScheme == .dark ? 0.12 : 0.06)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .allowsHitTesting(false)
                }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
        .overlay {
            if let border = pickupCardAccentBorder(card) {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(border, lineWidth: card.pill == .approved ? 1.5 : (card.pill == .canceledByOrganizer ? 1.35 : 1.25))
            }
        }
        .task(id: card.organizerUserId) {
            await viewModel.loadPickupCreatorDisplayNameIfNeeded(creatorUserId: card.organizerUserId)
        }
        .onAppear {
            if let row = viewModel.resolvedPickupGameRow(for: card.pickupGameId) {
                PickupGameStartedStateDebug.log(
                    row: row,
                    now: Date(),
                    allowedActions: "following_join_card,view_detail"
                )
            }
        }
    }

    private func pickupCardAccentBorder(_ card: PickupGameJoinRequestCardDisplay) -> Color? {
        switch card.pill {
        case .approved: return FGColor.accentGreen.opacity(0.38)
        case .declined: return FGColor.divider(followingColorScheme)
        case .canceledByOrganizer: return Color.red.opacity(followingColorScheme == .dark ? 0.42 : 0.32)
        default: return nil
        }
    }

    private func pickupJoinStatusPill(_ pill: PickupFollowingJoinRequestPillKind) -> some View {
        let colors = pickupJoinPillColors(pill)
        return Text(pill.title)
            .font(FGTypography.metadata)
            .fontWeight(.semibold)
            .foregroundStyle(colors.foreground)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(colors.background)
            .clipShape(Capsule())
            .overlay(Capsule().strokeBorder(colors.stroke, lineWidth: 1))
    }

    private func pickupJoinPillColors(_ pill: PickupFollowingJoinRequestPillKind) -> (background: Color, foreground: Color, stroke: Color) {
        switch pill {
        case .pending:
            return (
                FGColor.accentYellow.opacity(followingColorScheme == .dark ? 0.22 : 0.18),
                followingColorScheme == .dark ? Color.white.opacity(0.92) : Color.orange.opacity(0.95),
                FGColor.accentYellow.opacity(0.55)
            )
        case .approved:
            return (
                FGColor.accentGreen.opacity(0.16),
                FGColor.accentGreen,
                FGColor.accentGreen.opacity(0.42)
            )
        case .declined:
            return (
                Color.gray.opacity(followingColorScheme == .dark ? 0.22 : 0.14),
                FGColor.secondaryText(followingColorScheme),
                FGColor.divider(followingColorScheme)
            )
        case .cancelled:
            return (
                Color.gray.opacity(0.12),
                FGColor.mutedText(followingColorScheme),
                FGColor.divider(followingColorScheme).opacity(0.75)
            )
        case .withdrawing:
            return (
                Color.orange.opacity(followingColorScheme == .dark ? 0.18 : 0.12),
                Color.orange.opacity(followingColorScheme == .dark ? 0.95 : 0.88),
                Color.orange.opacity(0.45)
            )
        case .canceledByOrganizer:
            return (
                Color.red.opacity(followingColorScheme == .dark ? 0.28 : 0.16),
                Color.red.opacity(followingColorScheme == .dark ? 0.95 : 0.88),
                Color.red.opacity(0.45)
            )
        }
    }

    private var hasCompletedPlayingPickupFetch: Bool {
        guard let uid = viewModel.currentUserAuthId else { return true }
        return viewModel.lastSuccessfulFollowingJoinRequestsRefreshUserId == uid
            && viewModel.lastSuccessfulFollowingJoinRequestsRefreshAt != nil
    }

    private var shouldShowPlayingPickupLoadingState: Bool {
        guard viewModel.canFanUsePickupGamesUI, playingGameCards.isEmpty else { return false }
        if goingTabHasCachedContentForImmediatePaint() {
            return false
        }
        if viewModel.isPickupFollowingJoinListRefreshing { return true }
        if hasCompletedPlayingPickupFetch { return false }
        return goingTabPerf.backgroundRefreshInFlight || viewModel.isTabIntentPreloadInFlight("following")
    }

    private var shouldShowHostingPickupLoadingState: Bool {
        guard viewModel.canFanUsePickupGamesUI else { return false }
        guard viewModel.myPickupGamesForSettings.isEmpty,
              viewModel.myRemovedPickupGamesForSettings.isEmpty else { return false }
        return followingHostingPickupLoadInFlight || viewModel.myPickupGamesLightweightLoadTask != nil
    }

    private func openDiscoverFromGoing() {
#if DEBUG
        print("[AppleReviewFix] exploreDiscoverTapped")
#endif
        selectedTab = .discover
#if DEBUG
        print("[AppleReviewFix] selectedTab=\(MainTabView.AppTab.discover.rawValue)")
#endif
    }

    private func openDiscoverForPickupGamesFromGoing() {
        if viewModel.discoverMapContentMode != .pickupGames {
            viewModel.clearDiscoverMapContentSelectionsWhenSwitching(to: .pickupGames)
            viewModel.discoverMapContentMode = .pickupGames
        }
        if viewModel.discoverPickupSubMode != .games {
            viewModel.discoverPickupSubMode = .games
        }
        selectedTab = .discover
    }

    private func openCalendarProGamesFromGoing() {
#if DEBUG
        print("[AppleReviewFix] browseProGamesTapped")
#endif
        viewModel.calendarTabGameFilter = .proGames
        selectedTab = .calendar
#if DEBUG
        print("[AppleReviewFix] selectedTab=\(MainTabView.AppTab.calendar.rawValue)")
#endif
    }

    @ViewBuilder
    private func goingRichEmptyCard(
        title: String,
        description: String,
        buttonTitle: String? = nil,
        buttonAction: (() -> Void)? = nil
    ) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(FGTypography.cardTitle.weight(.bold))
                    .foregroundStyle(FGColor.primaryText(followingColorScheme))

                Text(description)
                    .font(FGTypography.caption)
                    .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                    .fixedSize(horizontal: false, vertical: true)
            }

            if let buttonTitle, let buttonAction {
                Button {
                    buttonAction()
                } label: {
                    Text(buttonTitle)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .background(
                            FGColor.accentGreen,
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                        )
                        .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
    }

    private func pickupSubtabLoadingCard(message: String) -> some View {
        HStack(spacing: 10) {
            ProgressView()
                .controlSize(.small)
            Text(message)
                .font(FGTypography.caption.weight(.medium))
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
    }

    private func emptyCard(icon: String, title: String, subtitle: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))

            Text(title)
                .font(FGTypography.cardTitle)
                .foregroundStyle(FGColor.primaryText(followingColorScheme))

            Text(subtitle)
                .font(FGTypography.caption)
                .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(18)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
    }

    @ViewBuilder
    private func followingVenueLeadingVisual(bar: BarVenue, sportRaw: String) -> some View {
        let side: CGFloat = 54
        let raw = sportRaw.trimmingCharacters(in: .whitespacesAndNewlines)
        let sportKey = raw.isEmpty ? bar.primarySport : raw
        Group {
            if let urlString = ImageDisplayURL.forList(thumbnail: bar.coverPhotoThumbnailURL, full: bar.coverPhotoURL),
               let url = URL(string: urlString) {
                DiscoverCachedRemoteImage(url: url, contentMode: .fill) {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(Color.primary.opacity(followingColorScheme == .dark ? 0.22 : 0.08))
                }
                .frame(width: side, height: side)
                .clipped()
            } else {
                let vis = SportFilterCatalog.resolve(sportKey)
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(vis.accent.opacity(followingColorScheme == .dark ? 0.24 : 0.15))
                    .frame(width: side, height: side)
                    .overlay {
                        Image(systemName: vis.systemImage)
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(vis.accent)
                    }
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func goingPlanCard(_ item: FollowingGoingDisplayItem, isCompleted: Bool) -> some View {
        let title = item.venueEvent.event_title ?? "Event"
        let bar = item.bar
        let sportRaw = item.venueEvent.sport ?? bar.primarySport
        let datePart = item.venueEvent.event_date ?? ""
        let timePart = item.venueEvent.event_time ?? ""
        let dateTimeLine = [datePart, timePart].filter { !$0.isEmpty }.joined(separator: " · ")
        let primaryText = isCompleted ? FGColor.mutedText(followingColorScheme) : FGColor.primaryText(followingColorScheme)
        let secondaryText = isCompleted ? FGColor.mutedText(followingColorScheme) : FGColor.secondaryText(followingColorScheme)

        return HStack(alignment: .top, spacing: 12) {
            followingVenueLeadingVisual(bar: bar, sportRaw: sportRaw)
                .opacity(isCompleted ? 0.55 : 1)

            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top, spacing: 10) {
                    Text(title)
                        .font(.title3.weight(.bold))
                        .foregroundStyle(primaryText)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)

                    Spacer(minLength: 8)

                    if isCompleted {
                        watchingCompletedPill
                    } else {
                        attendanceMenu(item: item)
                    }
                }

                if !dateTimeLine.isEmpty {
                    Label(dateTimeLine, systemImage: "calendar")
                        .font(FGTypography.caption.weight(.semibold))
                        .foregroundStyle(secondaryText)
                        .labelStyle(.titleAndIcon)
                }

                Button {
#if DEBUG
                    let matched = viewModel.bars.contains(where: { $0.id == bar.id })
                    print("[FollowingVenueOpen] venue=\(bar.name) matched=\(matched ? "mapRow" : "offMap")")
#endif
                    viewModel.requestDiscoverFocusForSavedVenue(bar)
                } label: {
                    Label(bar.name, systemImage: "mappin.and.ellipse")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(primaryText)
                        .labelStyle(.titleAndIcon)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
                .disabled(isCompleted)
                .accessibilityLabel("Open \(bar.name) on map")

                Button {
                    openFollowingDirectionsToVenue(bar: bar)
                } label: {
                    Text(bar.address)
                        .font(FGTypography.caption.weight(.semibold))
                        .foregroundStyle(isCompleted ? secondaryText : FGColor.accentBlue)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
                .disabled(isCompleted)
                .accessibilityLabel("Directions to \(bar.name)")

                if let bizEmail = VenueGameBusinessEmail.resolvedDisplayEmail(for: bar), !isCompleted {
                    VenueGameBusinessContactEmailRow(
                        email: bizEmail,
                        secondaryForeground: FGColor.secondaryText(followingColorScheme)
                    )
                    .padding(.top, 2)
                    .onAppear { VenueGameBusinessEmail.logDebug(bar: bar) }
                }

                if isCompleted {
                    Button {
                        Task { await clearWatchingVenueGame(item) }
                    } label: {
                        Label("Clear", systemImage: "xmark.circle")
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(FGColor.primaryText(followingColorScheme))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12, style: .continuous)
                                    .fill(Color.primary.opacity(followingColorScheme == .dark ? 0.14 : 0.07))
                            )
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Clear completed game from I’m Going")
                } else {
                    HStack(alignment: .center, spacing: 10) {
                        GoingAvatarStack(profiles: viewModel.goingProfiles(for: item.id), viewerUserID: viewModel.currentUserAuthId)
                        Label("\(item.attendeeCount) interested / going", systemImage: "person.2.fill")
                            .font(FGTypography.caption.weight(.semibold))
                            .foregroundStyle(secondaryText)
                            .labelStyle(.titleAndIcon)
                    }
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(
                    isCompleted
                        ? Color.primary.opacity(followingColorScheme == .dark ? 0.10 : 0.05)
                        : Color.clear
                )
        }
        .background {
            if !isCompleted {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(.ultraThinMaterial)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(
                    isCompleted
                        ? FGColor.divider(followingColorScheme).opacity(0.85)
                        : Color.clear,
                    lineWidth: 1
                )
        }
        .opacity(isCompleted ? 0.88 : 1)
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
        .task(id: item.id) {
            guard viewModel.isAuthenticatedForSocialFeatures, !isCompleted else { return }
            await viewModel.loadGoingUserProfiles(for: item.id)
        }
    }

    private var watchingCompletedPill: some View {
        Text("Ended")
            .font(.caption.weight(.bold))
            .foregroundStyle(FGColor.mutedText(followingColorScheme))
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(
                Capsule(style: .continuous)
                    .fill(Color.primary.opacity(followingColorScheme == .dark ? 0.16 : 0.08))
            )
            .overlay {
                Capsule(style: .continuous)
                    .strokeBorder(FGColor.divider(followingColorScheme), lineWidth: 1)
            }
            .accessibilityLabel("Game ended")
    }

    @MainActor
    private func clearWatchingVenueGame(_ item: FollowingGoingDisplayItem) async {
        guard viewModel.isAuthenticatedForSocialFeatures else { return }
#if DEBUG
        if WatchingExpiredVenueGameDiagnostics.enabled {
            print("[WatchingExpiredVenueGame] clear tapped event_id=\(item.id.uuidString.lowercased())")
        }
#endif
        setInterestedOnlyLocally(item.id, false)
        let ok = await viewModel.removeInterestInVenueEvent(venueEventID: item.id, refreshFollowing: true)
        if ok {
#if DEBUG
            if WatchingExpiredVenueGameDiagnostics.enabled {
                print("[WatchingExpiredVenueGame] clear success event_id=\(item.id.uuidString.lowercased())")
            }
#endif
            viewModel.showSocialActionToast("Removed from I’m Going.")
        } else {
#if DEBUG
            if WatchingExpiredVenueGameDiagnostics.enabled {
                print("[WatchingExpiredVenueGame] clear failed event_id=\(item.id.uuidString.lowercased()) error=removeInterestInVenueEvent")
            }
#endif
            viewModel.showSocialActionToast("Couldn't clear this game. Try again.")
        }
    }

    @ViewBuilder
    private func attendanceMenu(item: FollowingGoingDisplayItem) -> some View {
        if viewModel.isAuthenticatedForSocialFeatures {
            Menu {
                Button {
                    Task { await applyAttendance(item, target: .going) }
                } label: {
                    Label("Going ✅", systemImage: "checkmark.circle.fill")
                }

                Button {
                    Task { await applyAttendance(item, target: .interested) }
                } label: {
                    Label("Interested 👀", systemImage: "eye")
                }

                Button(role: .destructive) {
                    Task { await applyAttendance(item, target: .notGoing) }
                } label: {
                    Label("Not going ❌", systemImage: "xmark.circle")
                }
            } label: {
                attendancePill(item: item)
            }
            .buttonStyle(.plain)
        } else {
            attendancePill(item: item)
                .opacity(0.45)
        }
    }

    private func attendancePill(item: FollowingGoingDisplayItem) -> some View {
        let pillIsGoing = item.isServerGoing
        return HStack(spacing: 6) {
            Text(pillIsGoing ? "Going" : "Interested")
                .font(.caption)
                .fontWeight(.bold)
            Image(systemName: "chevron.down")
                .font(.caption2.weight(.bold))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(
            Capsule()
                .fill(pillIsGoing ? Color.green.opacity(0.22) : Color.orange.opacity(0.22))
        )
        .overlay(
            Capsule()
                .strokeBorder(pillIsGoing ? Color.green.opacity(0.45) : Color.orange.opacity(0.45), lineWidth: 1)
        )
        .foregroundStyle(pillIsGoing ? Color.green : Color.orange)
    }

    private func venueCard(_ bar: BarVenue) -> some View {
        let isFavorite = viewModel.favoriteVenueIDs.contains(bar.id)
        let sportRaw = bar.primarySport

        return ZStack(alignment: .topTrailing) {
            HStack(alignment: .top, spacing: 12) {
                followingVenueLeadingVisual(bar: bar, sportRaw: sportRaw)
                VStack(alignment: .leading, spacing: 8) {
                    Button {
                        viewModel.requestDiscoverFocusForSavedVenue(bar)
                    } label: {
                        Text(bar.name)
                            .font(.title3.weight(.bold))
                            .foregroundStyle(FGColor.primaryText(followingColorScheme))
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.trailing, 36)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Open \(bar.name) on map")

                    Label("Saved venue", systemImage: "building.2")
                        .font(FGTypography.caption.weight(.semibold))
                        .foregroundStyle(FGColor.secondaryText(followingColorScheme))
                        .labelStyle(.titleAndIcon)

                    Button {
                        openFollowingDirectionsToVenue(bar: bar)
                    } label: {
                        Text(bar.address)
                            .font(FGTypography.caption.weight(.semibold))
                            .foregroundStyle(FGColor.accentBlue)
                            .multilineTextAlignment(.leading)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Directions to \(bar.name)")

                    if let bizEmail = VenueGameBusinessEmail.resolvedDisplayEmail(for: bar) {
                        VenueGameBusinessContactEmailRow(
                            email: bizEmail,
                            secondaryForeground: FGColor.secondaryText(followingColorScheme)
                        )
                        .padding(.top, 2)
                        .onAppear { VenueGameBusinessEmail.logDebug(bar: bar) }
                    }

                    Button {
                        viewModel.requestDiscoverFocusForSavedVenue(bar)
                    } label: {
                        FlowTags(tags: bar.tags)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(14)

            Button {
                Task { await toggleSavedVenueHeart(bar: bar, currentlySaved: isFavorite) }
            } label: {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .font(.title3)
                    .foregroundStyle(isFavorite ? Color.red : Color.secondary)
                    .padding(10)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isFavorite ? "Remove from saved venues" : "Save venue")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .modifier(FollowingCardChromeModifier(colorScheme: followingColorScheme, cornerRadius: 22))
    }

    // MARK: - Maps / Discover (Following tab)

    /// Opens Apple Maps directions: uses venue coordinates when they look valid; otherwise falls back to encoded address (`daddr`).
    private func openFollowingDirectionsToVenue(bar: BarVenue) {
#if DEBUG
        print("[FollowingDirections] venue=\(bar.name) address=\(bar.address)")
#endif
        let trimmedAddress = bar.address.trimmingCharacters(in: .whitespacesAndNewlines)
        if Self.followingDirectionsCoordinateLooksUsable(bar.coordinate) {
            let location = CLLocation(latitude: bar.coordinate.latitude, longitude: bar.coordinate.longitude)
            let mapItem = MKMapItem(location: location, address: nil)
            mapItem.name = bar.name
            mapItem.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving])
            return
        }
        guard !trimmedAddress.isEmpty else { return }
        var components = URLComponents()
        components.scheme = "https"
        components.host = "maps.apple.com"
        components.queryItems = [URLQueryItem(name: "daddr", value: trimmedAddress)]
        guard let url = components.url else { return }
        UIApplication.shared.open(url)
    }

    private static func followingDirectionsCoordinateLooksUsable(_ c: CLLocationCoordinate2D) -> Bool {
        guard CLLocationCoordinate2DIsValid(c) else { return false }
        if abs(c.latitude) < 1e-5 && abs(c.longitude) < 1e-5 { return false }
        return abs(c.latitude) <= 90 && abs(c.longitude) <= 180
    }

    private func toggleSavedVenueHeart(bar: BarVenue, currentlySaved: Bool) async {
        guard viewModel.isAuthenticatedForSocialFeatures else { return }
        let wantSave = !currentlySaved
        let ok = await viewModel.setVenueFavorite(bar: bar, isFavorite: wantSave)
        if !ok {
            await MainActor.run {
                favoriteActionBanner = "Couldn’t update saved venue. Try again."
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
                    favoriteActionBanner = nil
                }
            }
        }
    }
}

/// Premium separation for Following list cards on `systemGroupedBackground` (stroke, soft lift, top-edge sheen).
private struct FollowingCardChromeModifier: ViewModifier {
    var colorScheme: ColorScheme
    var cornerRadius: CGFloat = 20
    private var shape: RoundedRectangle { RoundedRectangle(cornerRadius: cornerRadius, style: .continuous) }

    func body(content: Content) -> some View {
        let isLight = colorScheme == .light
        let shadowColor = Color.black.opacity(isLight ? 0.125 : 0.32)
        let shadowRadius: CGFloat = isLight ? 12 : 8
        let shadowY: CGFloat = isLight ? 3 : 2
        let outerStroke = FGColor.divider(colorScheme).opacity(isLight ? 0.92 : 0.88)
        let innerStroke = Color.white.opacity(isLight ? 0.10 : 0.04)
        let sheenTop = Color.white.opacity(isLight ? 0.16 : 0.04)

        content
            .shadow(color: shadowColor, radius: shadowRadius, x: 0, y: shadowY)
            .overlay {
                ZStack {
                    shape
                        .fill(
                            LinearGradient(
                                stops: [
                                    .init(color: sheenTop, location: 0),
                                    .init(color: Color.clear, location: 0.2)
                                ],
                                startPoint: .top,
                                endPoint: .bottom
                            )
                        )
                        .blendMode(.overlay)
                    shape
                        .strokeBorder(innerStroke, lineWidth: 0.5)
                        .padding(1)
                    shape
                        .strokeBorder(outerStroke, lineWidth: 1.35)
                }
                .allowsHitTesting(false)
            }
    }
}

private enum FollowingAttendanceTarget {
    case going
    case interested
    case notGoing

    var goingTabStatusDebugValue: String {
        switch self {
        case .going:
            return "going"
        case .interested:
            return "interested"
        case .notGoing:
            return "not_going"
        }
    }

    var isIncludedInGoingTab: Bool {
        switch self {
        case .going, .interested:
            return true
        case .notGoing:
            return false
        }
    }
}

private enum GoingParticipationMode: Hashable {
    case venueGames
    case pickupGames
    case proGames

    var title: String {
        switch self {
        case .venueGames: return "Venues"
        case .pickupGames: return "Pickup"
        case .proGames: return "Pro"
        }
    }

    var systemImage: String {
        switch self {
        case .venueGames: return "storefront.fill"
        case .pickupGames: return "person.3.fill"
        case .proGames: return "trophy.fill"
        }
    }

    var tint: Color {
        switch self {
        case .venueGames: return FGColor.accentGreen
        case .pickupGames: return FGColor.accentGreen
        case .proGames: return FGColor.accentBlue
        }
    }
}

private enum BusinessProGameFilter: Hashable {
    case all
    case myTeams
}

private struct PickupGameInviteDetailSheet: View {
    let item: PickupGameInviteDisplay
    let isResponding: Bool
    let onRespond: (String) async -> Void

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL

    private var game: PickupGameRow { item.game }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: FGSpacing.lg) {
                    hero
                    inviterLine
                    gameFacts
                    actionRow
                }
                .padding(FGSpacing.lg)
            }
            .scrollContentBackground(.hidden)
            .fanGeoScreenBackground()
            .navigationTitle("Invitation")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            LinearGradient(
                colors: [
                    FGColor.accentGreen.opacity(colorScheme == .dark ? 0.34 : 0.18),
                    FGColor.accentBlue.opacity(colorScheme == .dark ? 0.30 : 0.14),
                    Color.orange.opacity(colorScheme == .dark ? 0.22 : 0.10)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            SportArtworkIconView(sport: game.sport, diameter: 86)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.trailing, 24)
                .opacity(0.92)

            VStack(alignment: .leading, spacing: 8) {
                GameFormatBadgeView(format: game.gameFormat, colorScheme: colorScheme)
                Text(game.title)
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .foregroundStyle(FGColor.primaryText(colorScheme))
                    .fixedSize(horizontal: false, vertical: true)
                Text(AppSportCatalog.displayLabel(forSportToken: game.sport))
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(colorScheme))
            }
            .padding(FGSpacing.lg)
        }
        .frame(minHeight: 168)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(FGColor.divider(colorScheme).opacity(0.55), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(colorScheme == .dark ? 0.26 : 0.08), radius: 14, y: 6)
    }

    private var inviterLine: some View {
        HStack(spacing: 10) {
            UserAvatarView(
                avatarThumbnailURL: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_thumbnail_url),
                avatarURL: ImageDisplayURL.canonicalStorageURLString(item.inviterProfile?.avatar_url),
                avatarDisplayRefreshToken: UserAvatarView.stableRefreshToken(
                    userId: item.invite.inviter_user_id,
                    thumbnailURL: item.inviterProfile?.avatar_thumbnail_url,
                    avatarURL: item.inviterProfile?.avatar_url
                ),
                displayName: inviterName,
                email: item.inviterProfile?.email ?? "",
                size: 44,
                fallbackStyle: colorScheme == .dark ? .darkCardTranslucent : .lightOnWhiteChrome
            )
            VStack(alignment: .leading, spacing: 2) {
                Text("\(inviterName) invited you to")
                    .font(FGTypography.caption.weight(.semibold))
                    .foregroundStyle(FGColor.secondaryText(colorScheme))
                Text(game.title)
                    .font(FGTypography.cardTitle)
                    .foregroundStyle(FGColor.primaryText(colorScheme))
                    .lineLimit(2)
            }
        }
        .padding(FGSpacing.md)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(FGColor.divider(colorScheme).opacity(0.55), lineWidth: 1)
        )
    }

    private var gameFacts: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let dateLine = game.pickupDateWithCompactTimeRange {
                factRow("calendar", dateLine)
            }
            if !locationLine.isEmpty {
                factRow("mappin.and.ellipse", locationLine)
            }
            factRow("person.3", spotsOpenLine)
            if let lat = game.latitude, let lon = game.longitude {
                Button {
                    if let url = URL(string: "http://maps.apple.com/?ll=\(lat),\(lon)&q=Pickup%20game") {
                        openURL(url)
                    }
                } label: {
                    Label("View on map", systemImage: "map")
                        .font(FGTypography.metadata.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                }
                .buttonStyle(.bordered)
                .tint(FGColor.accentBlue)
            }
        }
        .padding(FGSpacing.md)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(FGColor.divider(colorScheme).opacity(0.55), lineWidth: 1)
        )
    }

    private func factRow(_ systemImage: String, _ text: String) -> some View {
        Label(text, systemImage: systemImage)
            .font(FGTypography.caption.weight(.semibold))
            .foregroundStyle(FGColor.secondaryText(colorScheme))
            .lineLimit(3)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var actionRow: some View {
        HStack(spacing: 8) {
            responseButton("Accept", status: "accepted", tint: FGColor.accentGreen)
            responseButton("Maybe", status: "maybe", tint: Color.orange)
            responseButton("Decline", status: "declined", tint: Color.red.opacity(0.9))
        }
    }

    private func responseButton(_ title: String, status: String, tint: Color) -> some View {
        Button {
            Task { await onRespond(status) }
        } label: {
            if isResponding {
                ProgressView()
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            } else {
                Text(title)
                    .font(FGTypography.metadata.weight(.bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
        }
        .buttonStyle(.borderedProminent)
        .tint(tint)
        .disabled(isResponding)
    }

    private var inviterName: String {
        let display = item.inviterProfile?.display_name?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !display.isEmpty { return display }
        let username = item.inviterProfile?.username?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !username.isEmpty { return username }
        return "A friend"
    }

    private var locationLine: String {
        [game.address, game.city, game.state]
            .compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .joined(separator: ", ")
    }

    private var spotsOpenLine: String {
        let open = game.pickupOpenSlotsRemaining
        return open == 1 ? "1 spot open" : "\(open) spots open"
    }
}

private enum GoingVenueTab: Hashable {
    case games
    case saved
}

private enum GoingGamesTab: Hashable {
    case playing
    case hosting
    case invites
}

private func decodeInterestedOnlyUUIDs(from encoded: String) -> Set<UUID> {
    let parts = encoded.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    var out: Set<UUID> = []
    for p in parts {
        if let u = UUID(uuidString: p) {
            out.insert(u)
        }
    }
    return out
}

private struct EquatableRenderCard<Token: Equatable, Content: View>: View, Equatable {
    let token: Token
    let content: () -> Content

    static func == (lhs: EquatableRenderCard<Token, Content>, rhs: EquatableRenderCard<Token, Content>) -> Bool {
        lhs.token == rhs.token
    }

    var body: some View {
        content()
    }
}

private struct PickupInviteRenderToken: Equatable {
    let id: UUID
    let game: PickupGameRow
    let inviterName: String
    let inviterAvatarThumbnailURL: String
    let inviterAvatarURL: String
    let isBusy: Bool
    let colorScheme: ColorScheme
}

private struct PickupPlayingCardRenderToken: Equatable {
    let card: PickupGameJoinRequestCardDisplay
    let resolvedGame: PickupGameRow?
    let organizerAvatarThumbnailURL: String?
    let organizerAvatarURL: String?
    let organizerAvatarRefreshToken: UUID
    let organizerEmail: String
    let currentUserId: UUID?
    let hasUnreadActivity: Bool
    let isRefreshSpinning: Bool
    let isWithdrawInFlight: Bool
    let lastJoinStatusRefreshAt: Date?
    let colorScheme: ColorScheme
}

private struct PickupHostedCardRenderToken: Equatable {
    let row: PickupGameRow
    let pendingJoinCount: Int
    let withdrawnJoinRows: [PickupGameRequestRow]
    let now: Date
    let colorScheme: ColorScheme
}

private func encodeInterestedOnlyUUIDs(_ set: Set<UUID>) -> String {
    set.map(\.uuidString).sorted().joined(separator: ",")
}

private struct FollowingMyPickupHostedGameDetailSheet: View {
    @ObservedObject var viewModel: MapViewModel
    @EnvironmentObject private var chatViewModel: ChatViewModel
    let game: PickupGameRow
    let now: Date
    let colorScheme: ColorScheme
    let onDone: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    let onManageRequests: () -> Void
    let onInvite: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                SettingsPickupMyGameListCard(
                    viewModel: viewModel,
                    row: game,
                    pendingJoinCount: viewModel.organizerPendingPickupJoinRequests(for: game.id),
                    withdrawnJoinRows: viewModel.pickupOrganizerWithdrawnRequestsByGameId[game.id] ?? [],
                    now: now,
                    colorScheme: colorScheme,
                    onEdit: onEdit,
                    onDelete: onDelete,
                    onManageRequests: onManageRequests,
                    onInvite: onInvite
                )
                .environmentObject(chatViewModel)
                .padding(.vertical, 8)
            }
            .fanGeoScreenBackground()
            .navigationTitle("Pickup game")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done", action: onDone)
                }
            }
        }
    }
}
